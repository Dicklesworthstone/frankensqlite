.mode list
.headers off
.print __issue530_9ce3af0ac525483092d314c44952baac_0
WITH t AS (SELECT value FROM generate_series(1,10000)) SELECT count(*) FROM t WHERE EXISTS(SELECT 1 FROM t t1 WHERE t.value=t1.value);
.print __issue530_9ce3af0ac525483092d314c44952baac_1
WITH t AS (SELECT value FROM generate_series(1,10000)) SELECT count(*) FROM t WHERE EXISTS(SELECT 1 FROM t t1 WHERE t.value=t1.value);
.print __issue530_9ce3af0ac525483092d314c44952baac_2
