.mode list
.headers off
.print __issue530_22d11c56b8ee4ee283e43710b6e63e96_0
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_22d11c56b8ee4ee283e43710b6e63e96_1
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_22d11c56b8ee4ee283e43710b6e63e96_2
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_22d11c56b8ee4ee283e43710b6e63e96_3
