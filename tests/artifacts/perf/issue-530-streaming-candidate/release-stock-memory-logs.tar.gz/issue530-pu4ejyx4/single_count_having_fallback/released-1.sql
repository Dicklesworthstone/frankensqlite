.mode list
.headers off
.print __issue530_c1f605d747aa428d9dc8cab6f4ebbde4_0
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_c1f605d747aa428d9dc8cab6f4ebbde4_1
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_c1f605d747aa428d9dc8cab6f4ebbde4_2
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_c1f605d747aa428d9dc8cab6f4ebbde4_3
