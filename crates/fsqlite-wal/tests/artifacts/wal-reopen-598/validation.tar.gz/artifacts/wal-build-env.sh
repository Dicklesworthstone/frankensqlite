source /workspace/scratch/e1a71523531b/toolchain/env.sh
export CARGO_TARGET_DIR=/workspace/scratch/e1a71523531b/artifacts/target-wal
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export RUSTFLAGS='-Zunstable-options --jobs-frontend=1 --jobs-backend=1 -Zfewer-names=yes -Ztime-passes=yes'
export MALLOC_CONF='abort_conf:true,narenas:1,dirty_decay_ms:0,muzzy_decay_ms:0,retain:false,tcache:false'
