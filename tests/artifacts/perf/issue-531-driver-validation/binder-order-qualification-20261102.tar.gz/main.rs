#![allow(dead_code)]
use fsqlite_ast::{Statement, SelectStatement};
use fsqlite_types::value::SqliteValue;
#[path="baseline.rs"] mod baseline;
#[path="candidate.rs"] mod candidate;
fn parse(sql: &str) -> SelectStatement {
    let (statement, consumed)=fsqlite_parser::parse_first_statement_with_tail(sql).unwrap().unwrap();
    assert_eq!(consumed,sql.len());
    let Statement::Select(select)=statement else { panic!("SELECT expected") };
    select
}
fn main() {
    let cases: Vec<(&str,&str,Vec<SqliteValue>)>=vec![
("wrapped_0_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_2","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_3","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(4),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_4","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(9223372036854775807),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_5","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-9223372036854775808),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_6","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_7","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.5),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_8","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Text("1".into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_9","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Null,SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_0_10","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Blob(vec![49].into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_2","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_3","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(4),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_4","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(9223372036854775807),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_5","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-9223372036854775808),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_6","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_7","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.5),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_8","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Text("1".into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_9","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Null,SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_1_10","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Blob(vec![49].into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_2","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_3","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(4),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_4","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(9223372036854775807),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_5","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-9223372036854775808),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_6","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_7","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.5),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_8","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Text("1".into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_9","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Null,SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_2_10","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -?1,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Blob(vec![49].into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_2","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_3","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(4),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_4","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(9223372036854775807),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_5","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-9223372036854775808),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_6","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_7","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.5),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_8","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Text("1".into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_9","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Null,SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_3_10","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY ?1 COLLATE BINARY,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Blob(vec![49].into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_2","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_3","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(4),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_4","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(9223372036854775807),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_5","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-9223372036854775808),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_6","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_7","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.5),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_8","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Text("1".into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_9","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Null,SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_4_10","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (+?1 COLLATE NOCASE) COLLATE RTRIM,p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Blob(vec![49].into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_2","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_3","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(4),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_4","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(9223372036854775807),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_5","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-9223372036854775808),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_6","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_7","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.5),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_8","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Text("1".into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_9","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Null,SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_5_10","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -(-(?1 COLLATE BINARY)),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Blob(vec![49].into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_2","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_3","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(4),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_4","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(9223372036854775807),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_5","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(-9223372036854775808),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_6","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.0),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_7","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Float(1.5),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_8","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Text("1".into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_9","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Null,SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("wrapped_6_10","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +(-?1 COLLATE BINARY),p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Blob(vec![49].into()),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("bound_zero_fold_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (?1 AND p.id),p.stamp DESC LIMIT 2",vec![SqliteValue::Integer(0)]),
("bound_zero_fold_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (?1 AND p.id),p.stamp DESC LIMIT 2",vec![SqliteValue::Integer(1)]),
("literal_ordinal_0","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY 1,p.stamp DESC LIMIT 2",vec![]),
("literal_ordinal_1","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +1,p.stamp DESC LIMIT 2",vec![]),
("literal_ordinal_2","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (-(-1) COLLATE BINARY),p.stamp DESC LIMIT 2",vec![]),
("literal_ordinal_3","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY 0,p.stamp DESC LIMIT 2",vec![]),
("literal_ordinal_4","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY -1,p.stamp DESC LIMIT 2",vec![]),
("literal_ordinal_5","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY 4,p.stamp DESC LIMIT 2",vec![]),
("literal_ordinal_6","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY +0 COLLATE NOCASE,p.stamp DESC LIMIT 2",vec![]),
("literal_ordinal_7","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (-4) COLLATE BINARY,p.stamp DESC LIMIT 2",vec![]),
("literal_ordinal_8","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY 9223372036854775807,p.stamp DESC LIMIT 2",vec![]),
("anonymous_textual_slots","SELECT ?+(SELECT count(*)+? FROM l WHERE l.pid=p.id AND l.val>?),p.id FROM p WHERE p.id>? ORDER BY +? COLLATE BINARY,p.stamp DESC LIMIT ? OFFSET ?",vec![SqliteValue::Integer(7),SqliteValue::Integer(11),SqliteValue::Integer(0),SqliteValue::Integer(0),SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(0)]),
("sparse_numbered_slots","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>?1 ORDER BY +?3 COLLATE BINARY,p.stamp DESC LIMIT ?2",vec![SqliteValue::Integer(0),SqliteValue::Integer(2),SqliteValue::Integer(1)]),
("repeated_named_and_prefixes","SELECT :key+(SELECT count(*) FROM l WHERE l.pid=p.id),p.id FROM p WHERE p.id>@key ORDER BY +$key COLLATE BINARY,p.stamp DESC LIMIT :amount",vec![SqliteValue::Integer(10),SqliteValue::Integer(0),SqliteValue::Integer(1),SqliteValue::Integer(2)]),
("nested_scalar_order","SELECT p.id,(SELECT l.val FROM l WHERE l.pid=p.id ORDER BY +?1 COLLATE BINARY,l.val DESC LIMIT 1) FROM p ORDER BY p.stamp DESC LIMIT 2",vec![SqliteValue::Integer(1)]),
("cte_order","WITH q AS (SELECT p.id,p.stamp FROM p ORDER BY +?1 COLLATE BINARY,p.stamp DESC LIMIT ?2) SELECT id,stamp FROM q ORDER BY stamp DESC",vec![SqliteValue::Integer(1),SqliteValue::Integer(2)]),
("negative_bound_offset","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p ORDER BY +?1,p.stamp DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(2),SqliteValue::Integer(-2)]),
("zero_bound_limit","SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p ORDER BY +?1,p.stamp DESC LIMIT ?2 OFFSET ?3",vec![SqliteValue::Integer(1),SqliteValue::Integer(0),SqliteValue::Null]),
    ];
    for (name,sql,values) in cases {
        let original=parse(sql);
        let before=baseline::ordinals(&original);
        let old=baseline::bind_ast(original.clone(),&values);
        let fixed=candidate::bind_ast(original,&values);
        assert_eq!(before,candidate::ordinals(&fixed),"ordinal status changed for {name}: {sql}");
        println!("{name}\tbaseline\t{:?}\t{:?}\t{}",before,baseline::ordinals(&old),old.to_string().replace('\n'," "));
        println!("{name}\tcandidate\t{:?}\t{:?}\t{}",before,candidate::ordinals(&fixed),fixed.to_string().replace('\n'," "));
    }
}
