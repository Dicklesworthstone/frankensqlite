use fsqlite_ast::{SelectStatement, Statement};
use fsqlite_parser::parse_first_statement_with_tail;
use fsqlite_vdbe::{
    ProgramBuilder,
    codegen::{
        CodegenContext, ColumnInfo, IndexSchema, TableSchema, codegen_delete, codegen_insert,
        codegen_select, codegen_update,
    },
};

fn parse_select(sql: &str) -> Result<SelectStatement, String> {
    let Some((stmt, consumed)) =
        parse_first_statement_with_tail(sql).map_err(|error| error.to_string())?
    else {
        return Err("expected a parsed SELECT statement".to_owned());
    };
    if consumed != sql.len() {
        return Err(format!(
            "parser consumed {consumed} bytes from a {} byte statement",
            sql.len()
        ));
    }

    match stmt {
        Statement::Select(select) => Ok(select),
        other => Err(format!("expected SELECT statement, got {other:?}")),
    }
}

fn parse_statement(sql: &str) -> Result<Statement, String> {
    let Some((stmt, consumed)) =
        parse_first_statement_with_tail(sql).map_err(|error| error.to_string())?
    else {
        return Err("expected a parsed statement".to_owned());
    };
    if consumed != sql.len() {
        return Err(format!(
            "parser consumed {consumed} bytes from a {} byte statement",
            sql.len()
        ));
    }

    Ok(stmt)
}

fn column(name: &str, affinity: char, is_ipk: bool) -> ColumnInfo {
    ColumnInfo::basic(name, affinity, is_ipk)
}

fn index(name: &str, root_page: i32, columns: &[&str], is_unique: bool) -> IndexSchema {
    IndexSchema {
        name: name.to_owned(),
        root_page,
        columns: columns.iter().map(|column| (*column).to_owned()).collect(),
        key_expressions: Vec::new(),
        key_sort_directions: Vec::new(),
        where_clause: None,
        is_unique,
        key_collations: Vec::new(),
        conflict_action: None,
    }
}

fn table(
    name: &str,
    root_page: i32,
    columns: Vec<ColumnInfo>,
    indexes: Vec<IndexSchema>,
) -> TableSchema {
    TableSchema {
        name: name.to_owned(),
        root_page,
        columns,
        indexes,
        strict: false,
        without_rowid: false,
        primary_key_constraints: Vec::new(),
        foreign_keys: Vec::new(),
        check_constraints: Vec::new(),
    }
}

fn snapshot_schema() -> Vec<TableSchema> {
    vec![
        table(
            "docs",
            2,
            vec![
                column("id", 'D', true),
                column("category_id", 'D', false),
                column("title", 'B', false),
                column("body", 'B', false),
                column("score", 'D', false),
            ],
            vec![
                index("idx_docs_category", 10, &["category_id"], false),
                index("idx_docs_title", 11, &["title"], false),
            ],
        ),
        table(
            "categories",
            3,
            vec![column("id", 'D', true), column("name", 'B', false)],
            vec![index("idx_categories_name", 12, &["name"], false)],
        ),
        table(
            "events",
            4,
            vec![
                column("id", 'D', true),
                column("category_id", 'D', false),
                column("score", 'D', false),
            ],
            vec![index("idx_events_category", 13, &["category_id"], false)],
        ),
    ]
}

/// GH#531: ordering an indexed lookup join must preserve the outer index
/// walk and place LIMIT on the joined output, without a full-result sorter.
#[test]
fn ordered_lookup_join_uses_outer_index_and_joined_row_limit() {
    use fsqlite_ast::SortDirection;
    use fsqlite_types::opcode::{Opcode, P4};

    let mut schema = snapshot_schema();
    let mut ordered = index("docs_score_id", 14, &["score", "id"], false);
    ordered.key_sort_directions = vec![SortDirection::Desc, SortDirection::Desc];
    schema[0].indexes.push(ordered);
    for (projection, ordering, reverse) in [
        ("d.id,c.name", "d.score DESC,d.id DESC", false),
        ("d.id,c.name", "d.score ASC,d.id ASC", true),
        (
            "d.score AS id,d.id AS score,c.name",
            "id DESC,score DESC",
            false,
        ),
        ("d.*,c.name", "5 DESC,1 DESC", false),
    ] {
        for join in ["JOIN", "LEFT JOIN"] {
            let sql = format!(
                "SELECT {projection} FROM docs d {join} categories c ON c.id=d.category_id \
                 WHERE d.id>1 ORDER BY {ordering} LIMIT ?1 OFFSET ?2"
            );
            let stmt = parse_select(&sql).unwrap();
            assert!(fsqlite_vdbe::codegen::join_select_streams_order_by(
                &stmt, &schema
            ));
            let mut builder = ProgramBuilder::new();
            codegen_select(
                &mut builder,
                &stmt,
                &schema,
                &CodegenContext {
                    index_ordered_scan_reliable: true,
                    ..CodegenContext::default()
                },
            )
            .unwrap();
            let program = builder.finish().unwrap();
            let ops = program.ops();
            let index_cursor = ops
                .iter()
                .find_map(|op| {
                    (op.opcode == Opcode::OpenRead
                        && matches!(&op.p4, P4::Index(name) if name == "docs_score_id"))
                    .then_some(op.p1)
                })
                .expect("outer ordering index");
            assert!(
                index_cursor <= 5,
                "{sql}: outer index cursor {index_cursor} must not grow the dense cursor table"
            );
            for opcode in [
                if reverse {
                    Opcode::Last
                } else {
                    Opcode::Rewind
                },
                if reverse { Opcode::Prev } else { Opcode::Next },
                Opcode::IdxRowid,
            ] {
                assert!(
                    ops.iter()
                        .any(|op| op.opcode == opcode && op.p1 == index_cursor),
                    "{sql}"
                );
            }
            assert!(
                !ops.iter().any(|op| op.opcode == Opcode::SorterOpen),
                "{sql}"
            );
            let output = ops
                .iter()
                .position(|op| op.opcode == Opcode::ResultRow)
                .unwrap();
            assert_eq!(ops[output + 1].opcode, Opcode::DecrJumpZero, "{sql}");
            assert_eq!(program.max_bind_parameter_index().unwrap(), 2);
        }
    }
}

#[test]
fn ordered_lookup_join_retains_sorter_when_order_is_not_proven() {
    use fsqlite_ast::SortDirection;
    use fsqlite_types::opcode::Opcode;

    let mut schema = snapshot_schema();
    let mut ordered = index("docs_score_id", 14, &["score", "id"], false);
    ordered.key_sort_directions = vec![SortDirection::Desc, SortDirection::Desc];
    schema[0].indexes.push(ordered);
    for suffix in [
        "ORDER BY d.score DESC",
        "ORDER BY c.name,d.id DESC",
        "ORDER BY d.score DESC NULLS FIRST,d.id DESC",
        "ORDER BY d.score DESC,d.id ASC",
    ] {
        let stmt = parse_select(&format!(
            "SELECT d.id,c.name FROM docs d JOIN categories c ON c.id=d.category_id \
             {suffix} LIMIT ?1"
        ))
        .unwrap();
        assert!(!fsqlite_vdbe::codegen::join_select_streams_order_by(
            &stmt, &schema
        ));
        let mut builder = ProgramBuilder::new();
        codegen_select(
            &mut builder,
            &stmt,
            &schema,
            &CodegenContext {
                index_ordered_scan_reliable: true,
                ..CodegenContext::default()
            },
        )
        .unwrap();
        let program = builder.finish().unwrap();
        assert!(
            program
                .ops()
                .iter()
                .any(|op| op.opcode == Opcode::SorterOpen),
            "{suffix}"
        );
    }

    // Explicit COLLATE already uses the connection's fallback because the
    // lookup-join compiler does not emit this expression. It must not be
    // admitted to the ordered index path merely because the columns match.
    let stmt = parse_select(
        "SELECT d.id,c.name FROM docs d JOIN categories c ON c.id=d.category_id \
         ORDER BY d.score COLLATE NOCASE DESC,d.id DESC LIMIT ?1",
    )
    .unwrap();
    assert!(!fsqlite_vdbe::codegen::join_select_streams_order_by(
        &stmt, &schema
    ));
    let mut builder = ProgramBuilder::new();
    assert!(matches!(
        codegen_select(
            &mut builder,
            &stmt,
            &schema,
            &CodegenContext {
                index_ordered_scan_reliable: true,
                ..CodegenContext::default()
            },
        ),
        Err(fsqlite_vdbe::codegen::CodegenError::Unsupported(_))
    ));
}

#[test]
fn ordered_lookup_join_preserves_selective_swapped_outer_seek() {
    use fsqlite_ast::SortDirection;
    use fsqlite_types::opcode::{Opcode, P4};

    let mut schema = snapshot_schema();
    let mut ordered = index("docs_score_id", 14, &["score", "id"], false);
    ordered.key_sort_directions = vec![SortDirection::Desc, SortDirection::Desc];
    schema[0].indexes.push(ordered);
    schema[1].columns.push(column("k", 'A', false));
    schema[1]
        .indexes
        .push(index("categories_k", 15, &["k"], false));
    let stmt = parse_select(
        "SELECT d.id,c.name FROM docs d JOIN categories c ON c.k=d.category_id \
         WHERE c.id=?1 ORDER BY d.score DESC,d.id DESC LIMIT ?2",
    )
    .unwrap();
    // The typeless-to-numeric swapped lookup can seek one category directly;
    // an available ordering index must not replace that with a full docs scan.
    assert!(!fsqlite_vdbe::codegen::join_select_streams_order_by(
        &stmt, &schema
    ));
    assert!(fsqlite_vdbe::codegen::join_select_seeks_outer_table(
        &stmt, &schema
    ));
    let mut builder = ProgramBuilder::new();
    codegen_select(
        &mut builder,
        &stmt,
        &schema,
        &CodegenContext {
            index_ordered_scan_reliable: true,
            ..CodegenContext::default()
        },
    )
    .unwrap();
    let program = builder.finish().unwrap();
    let ops = program.ops();
    assert!(ops.iter().any(|op| op.opcode == Opcode::OpenRead
        && op.p1 == 0
        && matches!(&op.p4, P4::Table(name) if name == "categories")));
    assert!(
        ops.iter()
            .any(|op| op.opcode == Opcode::SeekRowid && op.p1 == 0)
    );
    assert!(!ops.iter().any(|op| op.opcode == Opcode::OpenRead
        && matches!(&op.p4, P4::Index(name) if name == "docs_score_id")));
    assert!(!ops.iter().any(|op| op.opcode == Opcode::OpenAutoindex));
    assert!(ops.iter().any(|op| op.opcode == Opcode::SorterOpen));
}

