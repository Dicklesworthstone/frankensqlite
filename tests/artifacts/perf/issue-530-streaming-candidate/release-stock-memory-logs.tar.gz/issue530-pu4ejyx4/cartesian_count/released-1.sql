.mode list
.headers off
.print __issue530_911661a343084258ac01094741a2d7bd_0
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_911661a343084258ac01094741a2d7bd_1
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_911661a343084258ac01094741a2d7bd_2
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_911661a343084258ac01094741a2d7bd_3
