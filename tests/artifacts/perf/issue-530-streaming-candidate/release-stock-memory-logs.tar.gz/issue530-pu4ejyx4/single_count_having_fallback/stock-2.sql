.mode list
.headers off
.print __issue530_da36fa2d9e3a45afb73b17b1eef8e5a1_0
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_da36fa2d9e3a45afb73b17b1eef8e5a1_1
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_da36fa2d9e3a45afb73b17b1eef8e5a1_2
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_da36fa2d9e3a45afb73b17b1eef8e5a1_3
