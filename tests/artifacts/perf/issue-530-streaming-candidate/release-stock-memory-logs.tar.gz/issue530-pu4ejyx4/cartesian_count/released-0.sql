.mode list
.headers off
.print __issue530_87d93283a0b34fac92cc717a72901c2b_0
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_87d93283a0b34fac92cc717a72901c2b_1
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_87d93283a0b34fac92cc717a72901c2b_2
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_87d93283a0b34fac92cc717a72901c2b_3
