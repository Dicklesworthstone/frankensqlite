.mode list
.headers off
.print __issue530_4446088da7fe481886a8a99c498dc94b_0
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_4446088da7fe481886a8a99c498dc94b_1
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_4446088da7fe481886a8a99c498dc94b_2
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_4446088da7fe481886a8a99c498dc94b_3
