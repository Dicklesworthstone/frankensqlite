#!/usr/bin/env python3
"""Run the archived exact-source compiler lane; never rewrite repository sources.

The four phases are deliberately separate. Only the parent coordinator should
execute compilation. This is compiler/bytecode qualification, not SQL execution.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shlex
import shutil
import subprocess
import sys
import time


BASE = Path('/workspace/scratch/d1d8a2247ef3')
REPO = BASE / 'frankensqlite'
ROOT = Path(__file__).resolve().parent
TOOLCHAIN = Path('/workspace/scratch/a8cc6092effc/rust-toolchains/toolchains/nightly-2026-08-31-x86_64-unknown-linux-gnu/bin')
BASELINE = 'c5d04545807faf2d135e2dd561e76aa16d5bb95d'
SERIAL_FLAGS = '-Zunstable-options --jobs-frontend=1 --jobs-backend=1 -Zmir-opt-level=0 -Zmir-strip-debuginfo=all-locals'
DIRECT = ('fsqlite_ast', 'fsqlite_types', 'fsqlite_error', 'fsqlite_func',
          'fsqlite_parser', 'hashbrown', 'smallvec', 'tracing')
TESTS = {
    'grouped': 'crates/fsqlite-vdbe/tests/issue_531_grouped_index_input.rs',
    'ordered_lookup_join': 'crates/fsqlite-vdbe/tests/issue_531_ordered_lookup_join.rs',
}
LEAF_PATHS = ['Cargo.lock', 'Cargo.toml', '.cargo/config.toml'] + [
    f'crates/{name}' for name in ('fsqlite-types', 'fsqlite-error', 'fsqlite-ast',
                                 'fsqlite-parser', 'fsqlite-func')
]
SCOPE = ('Exact production codegen and ProgramBuilder/VdbeProgram source; '
         'real locked leaf dependencies; compiler/bytecode assertions only. '
         'No SQL storage runtime, query-result, transaction, or performance claim.')


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_digest(path: Path) -> str:
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def write_new(path: Path, value: object) -> None:
    with path.open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


def git(*arguments: str) -> bytes:
    return subprocess.check_output(['git', *arguments], cwd=REPO)


def build_environment() -> dict[str, str]:
    environment = os.environ.copy()
    environment.update({
        'PATH': str(TOOLCHAIN) + os.pathsep + environment.get('PATH', ''),
        'RUSTC': str(TOOLCHAIN / 'rustc'),
        'RUSTDOC': str(TOOLCHAIN / 'rustdoc'),
        'CARGO_HOME': str(BASE / 'cargo-home'),
        'CARGO_TARGET_DIR': str(BASE / 'target-531-serial'),
        'CARGO_BUILD_JOBS': '1',
        'CARGO_INCREMENTAL': '0',
        'CARGO_PROFILE_DEV_DEBUG': '0',
        'CARGO_PROFILE_TEST_DEBUG': '0',
        'RUSTFLAGS': SERIAL_FLAGS,
        'RUST_MIN_STACK': '8388608',
    })
    environment.pop('CARGO_ENCODED_RUSTFLAGS', None)
    # Preserve the existing debug-cache profile defaults, including its
    # compiler-chosen codegen-unit setting. An explicit override can fork all
    # fingerprints even when no production source changed.
    for key in ('CARGO_PROFILE_DEV_OPT_LEVEL', 'CARGO_PROFILE_DEV_CODEGEN_UNITS',
                'CARGO_PROFILE_DEV_LTO'):
        environment.pop(key, None)
    return environment


def ensure_session(session: Path, environment: dict[str, str]) -> None:
    if session.exists():
        if not (session / 'session.json').is_file():
            raise RuntimeError(f'Incomplete/non-driver session directory: {session}')
        return
    # Compare relevant real leaf sources/config against the baseline. Both
    # compiler arms must share genuinely identical leaves and dependency lock.
    changed = subprocess.run(['git', 'diff', '--quiet', BASELINE, '--', *LEAF_PATHS], cwd=REPO)
    if changed.returncode != 0:
        raise RuntimeError('Leaf sources/config differ from baseline; do not substitute artifacts')
    compiler = subprocess.check_output([str(TOOLCHAIN / 'rustc'), '-Vv'], env=environment, text=True)
    if '90850177249efe0321573c569aec5d12b257f8d6' not in compiler:
        raise RuntimeError('Unexpected compiler identity')
    cargo = subprocess.check_output([str(TOOLCHAIN / 'cargo'), '-V'], env=environment, text=True)
    session.mkdir(parents=True)
    keys = ['RUSTC', 'RUSTDOC', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
            'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
            'CARGO_PROFILE_DEV_OPT_LEVEL', 'CARGO_PROFILE_DEV_CODEGEN_UNITS',
            'CARGO_PROFILE_DEV_LTO', 'RUSTFLAGS', 'RUST_MIN_STACK']
    write_new(session / 'session.json', {
        'created_utc': stamp(), 'scope': SCOPE, 'repository': str(REPO),
        'head_at_session_start': git('rev-parse', 'HEAD').decode().strip(),
        'baseline_revision': BASELINE, 'cargo_lock_sha256': file_digest(REPO / 'Cargo.lock'),
        'driver_sha256': file_digest(Path(__file__)), 'rustc': compiler, 'cargo': cargo,
        'environment': {key: environment.get(key) for key in keys},
        'leaf_sources_equal_baseline': True,
        'archive_reused': 'grouped-codegen-20261102.tar.gz at c5d0454',
        'archive_sha256': '759c4bb578598968c7e0734565f63f8a6c99f3fba0c023eee99849e3e35ebd04',
        'profile_note': 'Leaf libraries use existing opt-level=1 debug-cache profile; '
                        'direct probe/test compilation uses opt-level=0. Both arms match.',
    })


def execute(session: Path, label: str, command: list[str], environment: dict[str, str]) -> dict:
    paths = {suffix: session / f'{label}.{suffix}'
             for suffix in ('started.json', 'json', 'stdout', 'stderr')}
    if any(path.exists() for path in paths.values()):
        raise RuntimeError(f'Evidence already exists for {label}; use a fresh --session')
    metadata = {'command': command, 'cwd': str(REPO), 'started_utc': stamp(),
                'scope': SCOPE, 'disk_free_before_bytes': shutil.disk_usage(session).free}
    write_new(paths['started.json'], metadata)
    started = time.monotonic()
    try:
        with paths['stdout'].open('x') as stdout, paths['stderr'].open('x') as stderr:
            result = subprocess.run(command, cwd=REPO, env=environment, stdout=stdout,
                                    stderr=stderr, check=False)
        metadata['exit_code'] = result.returncode
    except BaseException as error:
        metadata['error'] = repr(error)
        raise
    finally:
        metadata.update({'finished_utc': stamp(), 'elapsed_seconds': time.monotonic() - started,
                         'child_ru_maxrss_kib_cumulative': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                         'disk_free_after_bytes': shutil.disk_usage(session).free})
        write_new(paths['json'], metadata)
    print(json.dumps({'stage': label, 'exit_code': metadata['exit_code'],
                      'elapsed_seconds': metadata['elapsed_seconds']}), flush=True)
    return metadata


def collect_artifacts(session: Path) -> dict:
    artifacts = []
    search_paths = set()
    for line in (session / 'leaf-build.stdout').read_text().splitlines():
        if not line.strip():
            continue
        item = json.loads(line)
        if item.get('reason') == 'compiler-artifact':
            artifacts.append(item)
            search_paths.update('dependency=' + str(Path(name).parent)
                                for name in item.get('filenames', []))
        elif item.get('reason') == 'build-script-executed':
            search_paths.update(item.get('linked_paths', []))
    if any(item['target']['name'] == 'asupersync' for item in artifacts):
        raise RuntimeError('The leaf build unexpectedly compiled Asupersync')
    externs = {}
    for name in DIRECT:
        matches = [item for item in artifacts if item['target']['name'] == name
                   and 'lib' in item['target']['kind']]
        if len(matches) != 1:
            raise RuntimeError(f'Need one unambiguous Cargo artifact for {name}, got {len(matches)}')
        item = matches[0]
        pairs = {}
        for extension in ('.rlib', '.rmeta'):
            matching = [filename for filename in item['filenames'] if filename.endswith(extension)]
            if len(matching) != 1 or not Path(matching[0]).is_file():
                raise RuntimeError(f'Missing exact paired {extension} for {name}')
            pairs[extension[1:]] = matching[0]
        externs[name] = {**pairs, 'package_id': item['package_id'],
                         'features': item['features'], 'profile': item['profile']}
    return {'externs': externs, 'search_paths': sorted(search_paths),
            'leaf_message_sha256': file_digest(session / 'leaf-build.stdout')}


def native_flags(artifacts: dict) -> list[str]:
    flags = []
    for name in DIRECT:
        for extension in ('rlib', 'rmeta'):
            flags.extend(['--extern', f'{name}={artifacts["externs"][name][extension]}'])
    for search in artifacts['search_paths']:
        flags.extend(['-L', search])
    return flags


def snapshot_sources(session: Path) -> dict:
    existing = session / 'sources.json'
    if existing.exists():
        return json.loads(existing.read_text())
    sources = session / 'sources'
    sources.mkdir()
    manifest = {'created_utc': stamp(), 'scope': SCOPE, 'arms': {}, 'tests': {},
                'selection': ['lib.rs prefix before pub mod codegen;',
                              'unchanged complete codegen.rs included by path',
                              'lib.rs after pub mod vectorized_sort; and before PRAGMA Handling marker']}
    for arm in ('current', 'baseline'):
        directory = sources / arm
        directory.mkdir()
        content = {}
        for filename in ('lib.rs', 'codegen.rs'):
            path = 'crates/fsqlite-vdbe/src/' + filename
            data = (REPO / path).read_bytes() if arm == 'current' else git('show', f'{BASELINE}:{path}')
            (directory / filename).write_bytes(data)
            content[filename] = data
        production = content['lib.rs'].decode()
        prefix = production.split('pub mod codegen;', 1)[0]
        tail = production.split('pub mod vectorized_sort;', 1)[1]
        body = tail.split('// ── PRAGMA Handling', 1)[0]
        if len(body) == len(tail) or not prefix or not body:
            raise RuntimeError('Production extraction markers are missing')
        module_path = directory / 'codegen.rs'
        wrapper = prefix + f'#[path = {json.dumps(str(module_path))}]\npub mod codegen;' + body
        (directory / 'codegen_lib.rs').write_text(wrapper)
        manifest['arms'][arm] = {'baseline_revision': BASELINE if arm == 'baseline' else None,
                                 'production_lib_sha256': digest(content['lib.rs']),
                                 'codegen_sha256': digest(content['codegen.rs']),
                                 'wrapper_sha256': digest(wrapper.encode()),
                                 'source_directory': str(directory)}
    tests = sources / 'tests'
    tests.mkdir()
    for key, relative in TESTS.items():
        data = (REPO / relative).read_bytes()
        destination = tests / Path(relative).name
        destination.write_bytes(data)
        manifest['tests'][key] = {'repository_source': relative, 'snapshot': str(destination),
                                  'sha256': digest(data), 'same_file_for_both_arms': True}
    write_new(existing, manifest)
    return manifest


def common_rustc() -> list[str]:
    return [str(TOOLCHAIN / 'rustc'), '--edition=2024', '-C', 'opt-level=0',
            '-C', 'debuginfo=0', '-C', 'codegen-units=256', '-C', 'embed-bitcode=no',
            *shlex.split(SERIAL_FLAGS), '-C', 'link-arg=-Wl,--threads=1']


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['leaf-build', 'harness-build', 'test-build', 'run'])
    parser.add_argument('--session', required=True, help='Fresh evidence name; phases share its frozen sources')
    parser.add_argument('--arm', choices=['current', 'baseline', 'both'], default='both')
    parser.add_argument('--target', choices=[*TESTS, 'all'], default='all')
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', args.session):
        raise RuntimeError('Session must be a simple name without path separators')
    environment = build_environment()
    session = ROOT / 'runs' / args.session
    ensure_session(session, environment)
    arms = ('current', 'baseline') if args.arm == 'both' else (args.arm,)
    targets = tuple(TESTS) if args.target == 'all' else (args.target,)
    if args.phase == 'leaf-build':
        command = [str(TOOLCHAIN / 'cargo'), 'build', '--locked', '--offline', '-p',
                   'fsqlite-parser', '-p', 'fsqlite-func', '--no-default-features',
                   '--lib', '--message-format=json']
        result = execute(session, 'leaf-build', command, environment)
        if result['exit_code'] != 0:
            return 1
        write_new(session / 'leaf-artifacts.json', collect_artifacts(session))
        return 0
    artifacts = json.loads((session / 'leaf-artifacts.json').read_text())
    if json.loads((session / 'leaf-build.json').read_text())['exit_code'] != 0:
        raise RuntimeError('A successful real native leaf build is required')
    sources = snapshot_sources(session)
    flags = native_flags(artifacts)
    failures = []
    run_results = []
    for arm in arms:
        build = session / 'build' / arm
        build.mkdir(parents=True, exist_ok=True)
        library = build / 'libfsqlite_codegen_probe'
        if args.phase == 'harness-build':
            wrapper = Path(sources['arms'][arm]['source_directory']) / 'codegen_lib.rs'
            command = [*common_rustc(), '--crate-name', 'fsqlite_codegen_probe', '--crate-type',
                       'rlib', '--emit=metadata,link', str(wrapper), '--out-dir', str(build), *flags]
            result = execute(session, f'{arm}-harness-build', command, environment)
            failures.append(result['exit_code'] != 0)
            continue
        harness_result = json.loads((session / f'{arm}-harness-build.json').read_text())
        if harness_result['exit_code'] != 0:
            raise RuntimeError(f'{arm} harness did not compile')
        for target in targets:
            test = Path(sources['tests'][target]['snapshot'])
            binary = build / test.stem
            if args.phase == 'test-build':
                pair = ['--extern', f'fsqlite_vdbe={library}.rlib',
                        '--extern', f'fsqlite_vdbe={library}.rmeta', '-L', f'dependency={build}']
                command = [*common_rustc(), '--crate-name', test.stem, '--test', str(test),
                           '-o', str(binary), *pair, *flags]
            else:
                result = json.loads((session / f'{arm}-{target}-test-build.json').read_text())
                if result['exit_code'] != 0:
                    raise RuntimeError(f'{arm}/{target} test binary did not compile')
                command = [str(binary), '--test-threads=1', '--nocapture']
            label = f'{arm}-{target}-' + ('test-build' if args.phase == 'test-build' else 'run')
            result = execute(session, label, command, environment)
            failures.append(result['exit_code'] != 0)
            if args.phase == 'run':
                stdout = (session / f'{label}.stdout').read_text()
                counts = re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', stdout)
                run_results.append({'arm': arm, 'target': target, 'exit_code': result['exit_code'],
                                    'passed': int(counts[1]) if counts else None,
                                    'failed': int(counts[2]) if counts else None,
                                    'binary_sha256': file_digest(binary),
                                    'test_sha256': sources['tests'][target]['sha256'],
                                    'codegen_sha256': sources['arms'][arm]['codegen_sha256']})
    if args.phase == 'run':
        summary = session / f'results-{args.arm}-{args.target}.json'
        write_new(summary, {'scope': SCOPE, 'results': run_results,
                            'baseline_nonzero_is_preserved': True})
        print(json.dumps({'results': run_results, 'file': str(summary)}, indent=2))
    return int(any(failures))


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f'focused compiler driver: {error}', file=sys.stderr)
        raise SystemExit(1) from error
