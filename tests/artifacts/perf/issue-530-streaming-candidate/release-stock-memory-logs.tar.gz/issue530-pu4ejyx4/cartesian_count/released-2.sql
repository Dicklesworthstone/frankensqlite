.mode list
.headers off
.print __issue530_0fcef703d018451dbcc0a32e8623ee13_0
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_0fcef703d018451dbcc0a32e8623ee13_1
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_0fcef703d018451dbcc0a32e8623ee13_2
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_0fcef703d018451dbcc0a32e8623ee13_3
