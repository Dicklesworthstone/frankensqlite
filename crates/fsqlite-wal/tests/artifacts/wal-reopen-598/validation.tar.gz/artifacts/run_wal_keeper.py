"""Run one existing recovery keeper and preserve its exact local receipt."""
from pathlib import Path
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time

root = Path('/workspace/scratch/e1a71523531b')
repo = root / 'frankensqlite'
config = root / 'artifacts/wal-low-memory.toml'
keepers = {
    'wal-unit': ['--lib', 'wal::tests::', '--', '--skip', 'parallel_wal::', '--skip', 'cell_delta_wal::'],
    'wal-fault-matrix': ['--test', 'bd_xfn30_3_fault_injection_matrix'],
    'wal-recovery-invariants': ['--features', 'fault-injection', '--test', 'bd_db300_7_2_3_recovery_invariants'],
}
name = sys.argv[1]
label = sys.argv[2]
prefix = root / 'artifacts' / label
command = ['cargo', '-Zprofile-rustflags', '-Zprofile-hint-mostly-unused',
           '--config', str(config), 'test', '--locked', '--offline',
           '-j', '1', '-p', 'fsqlite-wal', *keepers[name]]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def identity():
    return {name: sha(repo / name) for name in [
        'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml',
        'crates/fsqlite-wal/Cargo.toml', 'crates/fsqlite-wal/src/wal.rs',
        'crates/fsqlite-wal/tests/wal_reopen.rs',
        'crates/fsqlite-wal/tests/bd_xfn30_3_fault_injection_matrix.rs',
        'crates/fsqlite-wal/tests/bd_db300_7_2_3_recovery_invariants.rs',
    ]}

receipt = {
    'command': command,
    'repository': str(repo),
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'source_hashes_before': identity(),
    'rustc': subprocess.check_output(['rustc', '-Vv'], text=True),
    'config': {'path': str(config), 'sha256': sha(config), 'content': config.read_text()},
    'overrides': {key: value for key, value in os.environ.items()
                  if key.startswith('CARGO_PROFILE_') or key in [
                      'CARGO_TARGET_DIR', 'CARGO_INCREMENTAL', 'CARGO_BUILD_JOBS', 'RUSTFLAGS', 'MALLOC_CONF']},
    'runner_sha256': sha(Path(__file__)),
    'started_unix_seconds': time.time(),
}
before = resource.getrusage(resource.RUSAGE_CHILDREN)
started = time.monotonic()
print(json.dumps({'command': command, 'log': str(prefix.with_suffix('.log'))}), flush=True)
with prefix.with_suffix('.log').open('xb') as stream:
    process = subprocess.Popen(command, cwd=repo, stdout=stream,
                               stderr=subprocess.STDOUT, start_new_session=True)
    try:
        returncode = process.wait(timeout=1800)
    except subprocess.TimeoutExpired:
        receipt['stop_reason'] = 'Keeper exceeded 1800 seconds'
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        returncode = process.returncode
after = resource.getrusage(resource.RUSAGE_CHILDREN)
receipt.update(returncode=returncode, elapsed_seconds=time.monotonic()-started,
               user_seconds=after.ru_utime-before.ru_utime,
               system_seconds=after.ru_stime-before.ru_stime,
               max_rss_kib=after.ru_maxrss, source_hashes_after=identity(),
               log_sha256=sha(prefix.with_suffix('.log')))
receipt['source_changed_during_run'] = receipt['source_hashes_before'] != receipt['source_hashes_after']
receipt['test_result_lines'] = [line for line in prefix.with_suffix('.log').read_text().splitlines()
                                if line.startswith('test result:')]
with Path(str(prefix) + '-receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt, indent=2), flush=True)
sys.exit(3 if receipt['source_changed_during_run'] else returncode)
