.mode list
.headers off
.print __issue530_83fd4a440c494ef0970861f93e36103e_0
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_83fd4a440c494ef0970861f93e36103e_1
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_83fd4a440c494ef0970861f93e36103e_2
