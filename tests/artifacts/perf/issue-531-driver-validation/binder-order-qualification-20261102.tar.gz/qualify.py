#!/usr/bin/env python3
"""Exact production binder slice plus locked leaves; no core SQL runtime claim."""
from pathlib import Path
import hashlib, json, os, subprocess, sys, time
ROOT=Path('/dev/shm/fsq531-binder-qualification')
TOOLCHAIN=Path('/workspace/scratch/c21f4a10b42a/rustup-home/toolchains/nightly-2026-08-31-x86_64-unknown-linux-gnu/bin')
LEAVES=Path('/dev/shm/fsqlite-issue531-d1d8a2247ef3/focused/runs/joins-v3/leaf-artifacts.json')
SQLITE='/workspace/scratch/d1d8a2247ef3/qualification/sqlite-3.53.2/sqlite3'
FIXTURE='CREATE TABLE p(id INTEGER PRIMARY KEY,stamp INTEGER);CREATE TABLE l(pid INTEGER,val INTEGER);INSERT INTO p VALUES(1,10),(2,30),(3,20);INSERT INTO l VALUES(1,10),(2,20),(2,30);'
CASES=[]
def case(name,sql,values,names=None):
 CASES.append(dict(name=name,sql=sql,values=values,names=names or ['?'+str(i+1) for i in range(len(values))]))
def val(kind,value=None):return [kind,value]
ints=[val('integer',x) for x in [1,0,-1,4,9223372036854775807,-9223372036854775808]]
values=ints+[val('real',1.0),val('real',1.5),val('text','1'),val('null'),val('blob','31')]
wrappers=['?1','+?1','-?1','?1 COLLATE BINARY','(+?1 COLLATE NOCASE) COLLATE RTRIM','-(-(?1 COLLATE BINARY))','+(-?1 COLLATE BINARY)']
for wi,wrapper in enumerate(wrappers):
 for vi,value in enumerate(values):
  case(f'wrapped_{wi}_{vi}',f'SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY {wrapper},p.stamp DESC,p.id DESC LIMIT ?2 OFFSET ?3',[value,val('integer',2),val('integer',0)])
for vi,value in enumerate([0,1]):
 case(f'bound_zero_fold_{vi}','SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY (?1 AND p.id),p.stamp DESC LIMIT 2',[val('integer',value)])
for i,order in enumerate(['1','+1','(-(-1) COLLATE BINARY)','0','-1','4','+0 COLLATE NOCASE','(-4) COLLATE BINARY','9223372036854775807']):
 case(f'literal_ordinal_{i}',f'SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>0 ORDER BY {order},p.stamp DESC LIMIT 2',[])
case('anonymous_textual_slots','SELECT ?+(SELECT count(*)+? FROM l WHERE l.pid=p.id AND l.val>?),p.id FROM p WHERE p.id>? ORDER BY +? COLLATE BINARY,p.stamp DESC LIMIT ? OFFSET ?',[val('integer',x) for x in [7,11,0,0,1,2,0]])
case('sparse_numbered_slots','SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p WHERE p.id>?1 ORDER BY +?3 COLLATE BINARY,p.stamp DESC LIMIT ?2',[val('integer',x) for x in [0,2,1]])
case('repeated_named_and_prefixes','SELECT :key+(SELECT count(*) FROM l WHERE l.pid=p.id),p.id FROM p WHERE p.id>@key ORDER BY +$key COLLATE BINARY,p.stamp DESC LIMIT :amount',[val('integer',x) for x in [10,0,1,2]],[':key','@key','$key',':amount'])
case('nested_scalar_order','SELECT p.id,(SELECT l.val FROM l WHERE l.pid=p.id ORDER BY +?1 COLLATE BINARY,l.val DESC LIMIT 1) FROM p ORDER BY p.stamp DESC LIMIT 2',[val('integer',1)])
case('cte_order','WITH q AS (SELECT p.id,p.stamp FROM p ORDER BY +?1 COLLATE BINARY,p.stamp DESC LIMIT ?2) SELECT id,stamp FROM q ORDER BY stamp DESC',[val('integer',1),val('integer',2)])
case('negative_bound_offset','SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p ORDER BY +?1,p.stamp DESC LIMIT ?2 OFFSET ?3',[val('integer',1),val('integer',2),val('integer',-2)])
case('zero_bound_limit','SELECT p.id,(SELECT count(*) FROM l WHERE l.pid=p.id) FROM p ORDER BY +?1,p.stamp DESC LIMIT ?2 OFFSET ?3',[val('integer',1),val('integer',0),val('null')])

def rust_value(value):
 k,v=value
 if k=='integer':return f'SqliteValue::Integer({v})'
 if k=='real':return f'SqliteValue::Float({v!r})'
 if k=='text':return 'SqliteValue::Text('+json.dumps(v)+'.into())'
 if k=='null':return 'SqliteValue::Null'
 if k=='blob':return 'SqliteValue::Blob(vec!['+','.join(str(x) for x in bytes.fromhex(v))+'].into())'
 raise ValueError(k)
def write_new(name,text):
 with (ROOT/name).open('x') as f:f.write(text)
def prepare():
 write_new('cases.json',json.dumps(CASES,indent=2)+'\n')
 entries=[]
 for c in CASES:
  entries.append('('+json.dumps(c['name'])+','+json.dumps(c['sql'])+',vec!['+','.join(map(rust_value,c['values']))+']),')
 main='''#![allow(dead_code)]
use fsqlite_ast::{Statement, SelectStatement};
use fsqlite_types::value::SqliteValue;
#[path="baseline.rs"] mod baseline;
#[path="candidate.rs"] mod candidate;
fn parse(sql: &str) -> SelectStatement {
    let (statement, consumed)=fsqlite_parser::parse_first_statement_with_tail(sql).unwrap().unwrap();
    assert_eq!(consumed,sql.len());
    let Statement::Select(select)=statement else { panic!("SELECT expected") };
    select
}
fn main() {
    let cases: Vec<(&str,&str,Vec<SqliteValue>)>=vec![
'''+ '\n'.join(entries)+'''
    ];
    for (name,sql,values) in cases {
        let original=parse(sql);
        let before=baseline::ordinals(&original);
        let old=baseline::bind_ast(original.clone(),&values);
        let fixed=candidate::bind_ast(original,&values);
        assert_eq!(before,candidate::ordinals(&fixed),"ordinal status changed for {name}: {sql}");
        println!("{name}\\tbaseline\\t{:?}\\t{:?}\\t{}",before,baseline::ordinals(&old),old.to_string().replace('\\n'," "));
        println!("{name}\\tcandidate\\t{:?}\\t{:?}\\t{}",before,candidate::ordinals(&fixed),fixed.to_string().replace('\\n'," "));
    }
}
'''
 write_new('main.rs',main)
 print(json.dumps({'cases':len(CASES),'main_bytes':len(main)}))
def build():
 artifacts=json.loads(LEAVES.read_text())
 command=[str(TOOLCHAIN/'rustc'),'--edition=2024','-C','opt-level=0','-C','debuginfo=0','-C','codegen-units=1','-C','embed-bitcode=no','-C','strip=symbols','-Zunstable-options','--jobs-frontend=1','--jobs-backend=1','-Zmir-opt-level=0','-Zmir-strip-debuginfo=all-locals','-C','link-arg=-Wl,--threads=1','--crate-name','binder_qualification',str(ROOT/'main.rs'),'-o',str(ROOT/'binder_qualification')]
 for name in ['fsqlite_ast','fsqlite_types','fsqlite_error','fsqlite_func','fsqlite_parser']:
  for kind in ['rlib','rmeta']:command+=['--extern',f'{name}={artifacts["externs"][name][kind]}']
 for path in artifacts['search_paths']:command+=['-L',path]
 env=os.environ.copy();env['TMPDIR']=str(ROOT);env['PATH']=str(TOOLCHAIN)+os.pathsep+env.get('PATH','')
 write_new('build-command.json',json.dumps(command,indent=2)+'\n')
 t=time.monotonic()
 p=subprocess.run(command,env=env,capture_output=True,text=True)
 write_new('build.stdout',p.stdout);write_new('build.stderr',p.stderr)
 write_new('build-result.json',json.dumps({'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t})+'\n')
 print(p.stderr[-4000:]);print('build exit',p.returncode)
 return p.returncode
def sql_value(value):
 k,v=value
 if k=='integer':return str(v)
 if k=='real':return repr(v)
 if k=='null':return 'NULL'
 if k=='blob':return "x'"+v+"'"
 if k=='text':return "'"+v.replace("'","''")+"'"
 raise ValueError(k)
def oracle(sql,values,names):
 commands=['.bail on','.mode quote','.parameter init']
 for name,value in zip(names,values):
  expression=sql_value(value)
  commands.append('.parameter set '+name+' '+json.dumps(expression))
 p=subprocess.run([SQLITE,':memory:'],input='\n'.join(commands)+'\n'+FIXTURE+'\n'+sql+';\n',capture_output=True,text=True)
 return dict(exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
def run():
 p=subprocess.run([str(ROOT/'binder_qualification')],capture_output=True,text=True)
 write_new('binder-run.stdout',p.stdout);write_new('binder-run.stderr',p.stderr)
 if p.returncode:print(p.stderr);return p.returncode
 transformed={}
 for line in p.stdout.splitlines():
  name,arm,before,after,sql=line.split('\t',4)
  transformed[(name,arm)]=dict(sql=sql,before=before,after=after)
 receipts=[];old_failures=[];fixed_failures=[]
 for c in CASES:
  expected=oracle(c['sql'],c['values'],c['names'])
  arms={}
  for arm in ['baseline','candidate']:
   emitted=transformed[(c['name'],arm)]
   actual=oracle(emitted['sql'],[],[])
   matches=(expected['exit_code']==actual['exit_code'] and expected['stdout']==actual['stdout'])
   arms[arm]=dict(**emitted,oracle=actual,matches=matches)
   if not matches:(old_failures if arm=='baseline' else fixed_failures).append(c['name'])
  receipts.append(dict(case=c,original=expected,arms=arms))
 write_new('oracle-receipts.json',json.dumps(receipts,indent=2)+'\n')
 summary={'scope':'Actual extracted Rust AST binder with real locked leaf dependencies, followed by C SQLite original-vs-bound SQL oracle; no native FrankenSQLite Connection/VDBE execution or performance claim.','sqlite_version':subprocess.check_output([SQLITE,'--version'],text=True).strip(),'cases':len(CASES),'baseline_mismatches':old_failures,'candidate_mismatches':fixed_failures,'candidate_source_sha256':hashlib.sha256((ROOT/'candidate.rs').read_bytes()).hexdigest(),'baseline_source_sha256':hashlib.sha256((ROOT/'baseline.rs').read_bytes()).hexdigest(),'main_sha256':hashlib.sha256((ROOT/'main.rs').read_bytes()).hexdigest()}
 write_new('summary.json',json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary,indent=2))
 return int(bool(fixed_failures))
if __name__=='__main__':
 phase=sys.argv[1]
 sys.exit({'prepare':prepare,'build':build,'run':run}[phase]() or 0)
