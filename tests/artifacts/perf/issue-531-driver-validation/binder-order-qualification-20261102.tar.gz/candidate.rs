use std::collections::HashMap;
use std::sync::Arc;
use fsqlite_ast::*;
use fsqlite_error::{FrankenError, Result};
use fsqlite_func::FunctionRegistry;
use fsqlite_types::limits::MAX_VARIABLE_NUMBER;
use fsqlite_types::value::SqliteValue;
#[derive(Clone)]
struct BindParamState {
    next_index: i32,
    named_indices: HashMap<NamedPlaceholderKey, i32>,
    function_registry: Option<Arc<FunctionRegistry>>,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct NamedPlaceholderKey {
    prefix: char,
    name: String,
}

impl Default for BindParamState {
    fn default() -> Self {
        Self {
            next_index: 1,
            named_indices: HashMap::new(),
            function_registry: None,
        }
    }
}

impl BindParamState {
    fn claim_anonymous(&mut self) -> Result<i32> {
        let index = self.next_index;
        if index <= 0 || u32::try_from(index).map_or(true, |n| n > MAX_VARIABLE_NUMBER) {
            return Err(FrankenError::OutOfRange {
                what: "placeholder index".to_owned(),
                value: index.to_string(),
            });
        }
        self.next_index =
            self.next_index
                .checked_add(1)
                .ok_or_else(|| FrankenError::OutOfRange {
                    what: "placeholder index".to_owned(),
                    value: index.to_string(),
                })?;
        Ok(index)
    }

    fn register_numbered(&mut self, index: i32) -> Result<i32> {
        if index <= 0 || u32::try_from(index).map_or(true, |n| n > MAX_VARIABLE_NUMBER) {
            return Err(FrankenError::OutOfRange {
                what: "placeholder index".to_owned(),
                value: index.to_string(),
            });
        }
        let next = index
            .checked_add(1)
            .ok_or_else(|| FrankenError::OutOfRange {
                what: "placeholder index".to_owned(),
                value: index.to_string(),
            })?;
        self.next_index = self.next_index.max(next);
        Ok(index)
    }

    fn register_named(&mut self, prefix: char, name: &str) -> Result<i32> {
        let key = NamedPlaceholderKey {
            prefix,
            name: name.to_owned(),
        };
        if let Some(index) = self.named_indices.get(&key) {
            return Ok(*index);
        }

        let index = self.claim_anonymous()?;
        self.named_indices.insert(key, index);
        Ok(index)
    }
}

fn placeholder_to_index(
    placeholder: &PlaceholderType,
    bind_state: &mut BindParamState,
) -> Result<i32> {
    match placeholder {
        PlaceholderType::Anonymous => bind_state.claim_anonymous(),
        PlaceholderType::Numbered(index) => {
            let index = i32::try_from(*index).map_err(|_| FrankenError::OutOfRange {
                what: "placeholder index".to_owned(),
                value: index.to_string(),
            })?;
            bind_state.register_numbered(index)
        }
        PlaceholderType::ColonNamed(name) => bind_state.register_named(':', name),
        PlaceholderType::AtNamed(name) => bind_state.register_named('@', name),
        PlaceholderType::DollarNamed(name) => bind_state.register_named('$', name),
    }
}


fn bind_placeholders_in_select_statement(
    select: &mut SelectStatement,
    bind_state: &mut BindParamState,
    params: &[SqliteValue],
) -> Result<()> {
    if let Some(with_clause) = &mut select.with {
        for cte in &mut with_clause.ctes {
            bind_placeholders_in_select_statement(&mut cte.query, bind_state, params)?;
        }
    }

    bind_placeholders_in_select_core(&mut select.body.select, bind_state, params)?;
    for (_, core) in &mut select.body.compounds {
        bind_placeholders_in_select_core(core, bind_state, params)?;
    }

    for ordering in &mut select.order_by {
        let was_ordinal = connection_order_by_integer_ordinal(&ordering.expr).is_some();
        bind_placeholders_in_expr(&mut ordering.expr, bind_state, params)?;
        // SQLite resolves ORDER BY ordinals from the original syntax. Binding
        // must not turn a parameter into an ordinal, including through unary
        // signs or COLLATE wrappers. Keep genuine ordinals unchanged so zero,
        // negative and out-of-range ones still receive their normal errors.
        if !was_ordinal && connection_order_by_integer_ordinal(&ordering.expr).is_some()
        {
            let span = ordering.expr.span();
            let bound_expr =
                std::mem::replace(&mut ordering.expr, Expr::Literal(Literal::Null, span));
            ordering.expr = Expr::BinaryOp {
                left: Box::new(Expr::Literal(Literal::Integer(0), span)),
                op: BinaryOp::Add,
                right: Box::new(bound_expr),
                span,
            };
        }
    }
    if let Some(limit_clause) = &mut select.limit {
        bind_placeholders_in_expr(&mut limit_clause.limit, bind_state, params)?;
        if let Some(offset) = &mut limit_clause.offset {
            bind_placeholders_in_expr(offset, bind_state, params)?;
        }
    }

    Ok(())
}

fn bind_placeholders_in_select_core(
    core: &mut SelectCore,
    bind_state: &mut BindParamState,
    params: &[SqliteValue],
) -> Result<()> {
    match core {
        SelectCore::Select {
            columns,
            from,
            where_clause,
            group_by,
            having,
            windows,
            ..
        } => {
            for column in columns {
                if let ResultColumn::Expr { expr, .. } = column {
                    bind_placeholders_in_expr(expr, bind_state, params)?;
                }
            }
            if let Some(from_clause) = from {
                bind_placeholders_in_from_clause(from_clause, bind_state, params)?;
            }
            if let Some(predicate) = where_clause {
                bind_placeholders_in_expr(predicate, bind_state, params)?;
            }
            for expr in group_by {
                bind_placeholders_in_expr(expr, bind_state, params)?;
            }
            if let Some(predicate) = having {
                bind_placeholders_in_expr(predicate, bind_state, params)?;
            }
            for window in windows {
                bind_placeholders_in_window_spec(&mut window.spec, bind_state, params)?;
            }
        }
        SelectCore::Values(rows) => {
            for row in rows.iter_mut() {
                for expr in row {
                    bind_placeholders_in_expr(expr, bind_state, params)?;
                }
            }
        }
    }
    Ok(())
}

fn bind_placeholders_in_from_clause(
    from: &mut fsqlite_ast::FromClause,
    bind_state: &mut BindParamState,
    params: &[SqliteValue],
) -> Result<()> {
    bind_placeholders_in_table_or_subquery(&mut from.source, bind_state, params)?;
    for join in &mut from.joins {
        bind_placeholders_in_table_or_subquery(&mut join.table, bind_state, params)?;
        if let Some(JoinConstraint::On(expr)) = &mut join.constraint {
            bind_placeholders_in_expr(expr, bind_state, params)?;
        }
    }
    Ok(())
}

fn bind_placeholders_in_table_or_subquery(
    source: &mut TableOrSubquery,
    bind_state: &mut BindParamState,
    params: &[SqliteValue],
) -> Result<()> {
    match source {
        TableOrSubquery::Table { .. } => {}
        TableOrSubquery::Subquery { query, .. } => {
            bind_placeholders_in_select_statement(query, bind_state, params)?;
        }
        TableOrSubquery::TableFunction { args, .. } => {
            for arg in args {
                bind_placeholders_in_expr(arg, bind_state, params)?;
            }
        }
        TableOrSubquery::ParenJoin(from_clause) => {
            bind_placeholders_in_from_clause(from_clause, bind_state, params)?;
        }
    }
    Ok(())
}

fn bind_placeholders_in_window_spec(
    spec: &mut fsqlite_ast::WindowSpec,
    bind_state: &mut BindParamState,
    params: &[SqliteValue],
) -> Result<()> {
    for expr in &mut spec.partition_by {
        bind_placeholders_in_expr(expr, bind_state, params)?;
    }
    for ordering in &mut spec.order_by {
        bind_placeholders_in_expr(&mut ordering.expr, bind_state, params)?;
    }
    if let Some(frame) = &mut spec.frame {
        bind_placeholders_in_frame_bound(&mut frame.start, bind_state, params)?;
        if let Some(end) = &mut frame.end {
            bind_placeholders_in_frame_bound(end, bind_state, params)?;
        }
    }
    Ok(())
}

fn bind_placeholders_in_frame_bound(
    bound: &mut fsqlite_ast::FrameBound,
    bind_state: &mut BindParamState,
    params: &[SqliteValue],
) -> Result<()> {
    match bound {
        fsqlite_ast::FrameBound::Preceding(expr) | fsqlite_ast::FrameBound::Following(expr) => {
            bind_placeholders_in_expr(expr, bind_state, params)?;
        }
        fsqlite_ast::FrameBound::UnboundedPreceding
        | fsqlite_ast::FrameBound::CurrentRow
        | fsqlite_ast::FrameBound::UnboundedFollowing => {}
    }
    Ok(())
}

fn bind_placeholder_to_literal(
    placeholder: &PlaceholderType,
    bind_state: &mut BindParamState,
    params: &[SqliteValue],
) -> Result<Literal> {
    let param_index = placeholder_to_index(placeholder, bind_state)?;
    let one_based = usize::try_from(param_index).map_err(|_| FrankenError::OutOfRange {
        what: "bind parameter index".to_owned(),
        value: param_index.to_string(),
    })?;
    if one_based == 0 || one_based > params.len() {
        return Err(FrankenError::OutOfRange {
            what: "bind parameter index".to_owned(),
            value: param_index.to_string(),
        });
    }
    Ok(sqlite_value_to_literal(&params[one_based - 1]))
}


fn sqlite_value_to_literal(value: &SqliteValue) -> Literal {
    match value {
        SqliteValue::Null => Literal::Null,
        SqliteValue::Integer(v) => Literal::Integer(*v),
        SqliteValue::Float(v) => Literal::Float(*v),
        SqliteValue::Text(v) => Literal::String(v.to_string()),
        SqliteValue::Blob(v) => Literal::Blob(v.to_vec()),
    }
}


#[allow(clippy::too_many_lines)]
fn bind_placeholders_in_expr(
    expr: &mut Expr,
    bind_state: &mut BindParamState,
    params: &[SqliteValue],
) -> Result<()> {
    match expr {
        Expr::BoundOuterValue { .. }
        | Expr::Literal(_, _)
        | Expr::Column(_, _)
        | Expr::Raise { .. } => {}
        Expr::BinaryOp { left, right, .. } => {
            bind_placeholders_in_expr(left, bind_state, params)?;
            bind_placeholders_in_expr(right, bind_state, params)?;
        }
        Expr::UnaryOp { expr: inner, .. }
        | Expr::Cast { expr: inner, .. }
        | Expr::Collate { expr: inner, .. }
        | Expr::IsNull { expr: inner, .. } => {
            bind_placeholders_in_expr(inner, bind_state, params)?;
        }
        Expr::Between {
            expr: inner,
            low,
            high,
            ..
        } => {
            bind_placeholders_in_expr(inner, bind_state, params)?;
            bind_placeholders_in_expr(low, bind_state, params)?;
            bind_placeholders_in_expr(high, bind_state, params)?;
        }
        Expr::In {
            expr: inner, set, ..
        } => {
            bind_placeholders_in_expr(inner, bind_state, params)?;
            match set {
                InSet::List(values) => {
                    for value in values {
                        bind_placeholders_in_expr(value, bind_state, params)?;
                    }
                }
                InSet::Subquery(query) => {
                    bind_placeholders_in_select_statement(query, bind_state, params)?;
                }
                InSet::Table(_) => {}
            }
        }
        Expr::Like {
            expr: inner,
            pattern,
            escape,
            ..
        } => {
            bind_placeholders_in_expr(inner, bind_state, params)?;
            bind_placeholders_in_expr(pattern, bind_state, params)?;
            if let Some(escape_expr) = escape {
                bind_placeholders_in_expr(escape_expr, bind_state, params)?;
            }
        }
        Expr::Case {
            operand,
            whens,
            else_expr,
            ..
        } => {
            if let Some(base) = operand {
                bind_placeholders_in_expr(base, bind_state, params)?;
            }
            for (when_expr, then_expr) in whens {
                bind_placeholders_in_expr(when_expr, bind_state, params)?;
                bind_placeholders_in_expr(then_expr, bind_state, params)?;
            }
            if let Some(else_branch) = else_expr {
                bind_placeholders_in_expr(else_branch, bind_state, params)?;
            }
        }
        Expr::Exists { subquery, .. } | Expr::Subquery(subquery, _) => {
            bind_placeholders_in_select_statement(subquery, bind_state, params)?;
        }
        Expr::FunctionCall {
            args,
            order_by,
            filter,
            over,
            ..
        } => {
            if let FunctionArgs::List(arguments) = args {
                for arg in arguments {
                    bind_placeholders_in_expr(arg, bind_state, params)?;
                }
            }
            for ordering in order_by {
                bind_placeholders_in_expr(&mut ordering.expr, bind_state, params)?;
            }
            if let Some(filter_expr) = filter {
                bind_placeholders_in_expr(filter_expr, bind_state, params)?;
            }
            if let Some(window_spec) = over {
                bind_placeholders_in_window_spec(window_spec, bind_state, params)?;
            }
        }
        Expr::JsonAccess {
            expr: inner, path, ..
        } => {
            bind_placeholders_in_expr(inner, bind_state, params)?;
            bind_placeholders_in_expr(path, bind_state, params)?;
        }
        Expr::RowValue(values, _) => {
            for value in values {
                bind_placeholders_in_expr(value, bind_state, params)?;
            }
        }
        Expr::Placeholder(placeholder, span) => {
            let literal = bind_placeholder_to_literal(placeholder, bind_state, params)?;
            *expr = Expr::Literal(literal, *span);
        }
    }
    Ok(())
}


fn expr_folds_to_integer_zero_via_and(expr: &Expr) -> bool {
    match expr {
        Expr::Literal(Literal::Integer(0), _) => true,
        Expr::BinaryOp {
            left,
            op: BinaryOp::And,
            right,
            ..
        } => expr_folds_to_integer_zero_via_and(left) || expr_folds_to_integer_zero_via_and(right),
        _ => false,
    }
}


fn connection_order_by_integer_ordinal(expr: &Expr) -> Option<i64> {
    if expr_folds_to_integer_zero_via_and(expr) {
        return Some(0);
    }
    match expr {
        Expr::Literal(Literal::Integer(value), _) => Some(*value),
        Expr::UnaryOp {
            op: UnaryOp::Plus,
            expr,
            ..
        }
        | Expr::Collate { expr, .. } => connection_order_by_integer_ordinal(expr),
        Expr::UnaryOp {
            op: UnaryOp::Negate,
            expr,
            ..
        } => connection_order_by_integer_ordinal(expr)?.checked_neg(),
        _ => None,
    }
}


pub fn bind_ast(mut select: SelectStatement, values: &[SqliteValue]) -> SelectStatement {
    bind_placeholders_in_select_statement(&mut select, &mut BindParamState::default(), values).unwrap();
    select
}
pub fn ordinals(select: &SelectStatement) -> Vec<Option<i64>> {
    select.order_by.iter().map(|term| connection_order_by_integer_ordinal(&term.expr)).collect()
}
