.mode list
.headers off
.print __issue530_960a96bdd81348278baa12b23407355b_0
WITH t AS (SELECT value FROM generate_series(1,1000000)) SELECT count(*) FROM t;
.print __issue530_960a96bdd81348278baa12b23407355b_1
WITH t AS (SELECT value FROM generate_series(1,1000000)) SELECT count(*) FROM t;
.print __issue530_960a96bdd81348278baa12b23407355b_2
