.mode list
.headers off
.print __issue530_f3935b856b764c9fbc95b99feebf12f2_0
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_f3935b856b764c9fbc95b99feebf12f2_1
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_f3935b856b764c9fbc95b99feebf12f2_2
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_f3935b856b764c9fbc95b99feebf12f2_3
