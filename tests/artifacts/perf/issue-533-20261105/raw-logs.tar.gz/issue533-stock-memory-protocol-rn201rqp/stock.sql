.mode list
.headers off
.print __issue530_bc0c4bddd0f94f309e8802d076074d70_0
SELECT count(*) FROM generate_series(1,1000);
.print __issue530_bc0c4bddd0f94f309e8802d076074d70_1
SELECT count(*) FROM generate_series(1,1000);
.print __issue530_bc0c4bddd0f94f309e8802d076074d70_2
