import hashlib,json,os,pathlib,resource,subprocess,time
CACHE=pathlib.Path('/workspace/scratch/d1d8a2247ef3/target-531-serial/debug/build')
REPO=pathlib.Path('/workspace/scratch/c21f4a10b42a/frankensqlite')
OUT=pathlib.Path('/dev/fsq531')
RUSTC='/workspace/scratch/c21f4a10b42a/rustup-home/toolchains/nightly-2026-08-31-x86_64-unknown-linux-gnu/bin/rustc'
choices={}
for p in CACHE.glob('*/*/fingerprint/lib-*.json'):
 f=p.with_suffix('')
 if not f.is_file():continue
 name=p.stem.removeprefix('lib-')
 value=int.from_bytes(bytes.fromhex(f.read_text().strip()),'little')
 choices[(name,value)]=p

def external(name,value):
 p=choices.get((name,value))
 if p is None:raise RuntimeError(f'missing exact fingerprint {name} {value}')
 outputs=p.parent.parent/'out'
 found=list(outputs.glob(f'lib{name}-*.rmeta'))
 if not found:found=list(outputs.glob(f'lib{name}-*.so'))
 if len(found)!=1:raise RuntimeError(f'nonunique artifact {name} {found}')
 return found[0]

def compile(crate,artifact_id,overrides):
 p=CACHE/crate/artifact_id/'fingerprint'/('lib-'+crate.replace('-','_')+'.json')
 spec=json.loads(p.read_text())
 name=crate.replace('-','_')
 target=OUT/('lib'+name+'-issue531.rmeta')
 command=[RUSTC,'--crate-name',name,'--edition=2024','--crate-type','lib',str(REPO/'crates'/crate/'src/lib.rs'),'--emit=metadata='+str(target),'-Cmetadata=issue531native','-Copt-level=0','-Cdebuginfo=0','-Zunstable-options','--jobs-frontend=1','--jobs-backend=1','-Zmir-opt-level=0','-Zmir-strip-debuginfo=all-locals']
 for feature in json.loads(spec['features']):command+=['--cfg',f'feature="{feature}"']
 command+=['--check-cfg','cfg(feature, values('+','.join('"'+f+'"' for f in json.loads(spec['declared_features']))+'))']
 for _,dep,_,value in spec['deps']:
  path=overrides.get(dep) or external(dep,value)
  command+=['--extern',dep+'='+str(path)]
 for path in CACHE.glob('*/*/out'):
  command+=['-L','dependency='+str(path)]
 command+=['-L','dependency='+str(OUT)]
 env=os.environ.copy()
 env.update(CARGO_MANIFEST_DIR=str(REPO/'crates'/crate),CARGO_PKG_VERSION='0.4.13',CARGO_PKG_NAME=crate,CARGO_PKG_DESCRIPTION='FrankenSQLite',CARGO_PKG_VERSION_MAJOR='0',CARGO_PKG_VERSION_MINOR='4',CARGO_PKG_VERSION_PATCH='13',CARGO_PKG_VERSION_PRE='',TMPDIR=str(OUT))
 source=REPO/'crates'/crate/'src'/('codegen.rs' if crate=='fsqlite-vdbe' else 'connection.rs')
 before=hashlib.sha256(source.read_bytes()).hexdigest()
 prefix=OUT/(crate+'-native-check')
 prefix.with_suffix('.command.json').write_text(json.dumps({'command':command,'source':str(source),'source_sha256_before':before,'features':spec['features']},indent=2))
 started=time.monotonic()
 with prefix.with_suffix('.log').open('w') as log:result=subprocess.run(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
 record={'crate':crate,'exit':result.returncode,'elapsed_seconds':time.monotonic()-started,'max_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'source_sha256_before':before,'source_sha256_after':hashlib.sha256(source.read_bytes()).hexdigest(),'log':str(prefix.with_suffix('.log'))}
 prefix.with_suffix('.result.json').write_text(json.dumps(record,indent=2))
 print(json.dumps(record),flush=True)
 if result.returncode:print(prefix.with_suffix('.log').read_text(),flush=True);raise SystemExit(result.returncode)
 return target
vdbe=compile('fsqlite-vdbe','755ae877fb74b653',{})
compile('fsqlite-core','d756f7bc2e3ca871',{'fsqlite_vdbe':vdbe})
