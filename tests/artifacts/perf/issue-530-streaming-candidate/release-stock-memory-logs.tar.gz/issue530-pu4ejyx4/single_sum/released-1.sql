.mode list
.headers off
.print __issue530_ddd4c22d48fb4edea5f111c897f2edb8_0
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_ddd4c22d48fb4edea5f111c897f2edb8_1
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_ddd4c22d48fb4edea5f111c897f2edb8_2
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_ddd4c22d48fb4edea5f111c897f2edb8_3
