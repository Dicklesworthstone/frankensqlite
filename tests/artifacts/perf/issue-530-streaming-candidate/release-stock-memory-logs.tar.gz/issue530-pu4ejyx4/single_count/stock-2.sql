.mode list
.headers off
.print __issue530_ce14b08eb6644beda324bbcf5c3cf288_0
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_ce14b08eb6644beda324bbcf5c3cf288_1
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_ce14b08eb6644beda324bbcf5c3cf288_2
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_ce14b08eb6644beda324bbcf5c3cf288_3
