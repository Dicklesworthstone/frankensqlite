.mode list
.headers off
.print __issue530_ae73063ec50342ed90029494ee8f9f15_0
WITH t AS (SELECT value FROM generate_series(1,1000000)) SELECT count(*) FROM t;
.print __issue530_ae73063ec50342ed90029494ee8f9f15_1
WITH t AS (SELECT value FROM generate_series(1,1000000)) SELECT count(*) FROM t;
.print __issue530_ae73063ec50342ed90029494ee8f9f15_2
