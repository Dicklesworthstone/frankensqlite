.mode list
.headers off
.print __issue530_29332c92cfe7411eb8adfea6732c376f_0
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_29332c92cfe7411eb8adfea6732c376f_1
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_29332c92cfe7411eb8adfea6732c376f_2
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_29332c92cfe7411eb8adfea6732c376f_3
