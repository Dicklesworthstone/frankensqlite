.mode list
.headers off
.print __issue530_fe7b7f633cf14cb7abea43efb7d78928_0
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_fe7b7f633cf14cb7abea43efb7d78928_1
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_fe7b7f633cf14cb7abea43efb7d78928_2
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_fe7b7f633cf14cb7abea43efb7d78928_3
