.mode list
.headers off
EXPLAIN QUERY PLAN SELECT count(*) FROM generate_series(1,10000)t WHERE EXISTS(SELECT 1 FROM generate_series(1,10000) t1 WHERE t.value=t1.value);
