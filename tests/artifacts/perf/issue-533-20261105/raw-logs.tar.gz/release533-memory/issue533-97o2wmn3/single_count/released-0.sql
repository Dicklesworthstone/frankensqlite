.mode list
.headers off
.print __issue530_487e1e00dad0485ba11d1aaa23dde690_0
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_487e1e00dad0485ba11d1aaa23dde690_1
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_487e1e00dad0485ba11d1aaa23dde690_2
