#!/usr/bin/env python3
"""Compile unchanged codegen sources and execute physical-bytecode assertions.

This excludes VDBE execution, storage, SQL result, and timing qualification.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ARCHIVE = Path('/dev/shm/fsqlite-issue531-d1d8a2247ef3/focused/runs/joins-v3')
OLD_DRIVER = Path('/workspace/scratch/d1d8a2247ef3/qualification/continuation-focused/driver.py')
REPO = Path('/workspace/scratch/c21f4a10b42a/frankensqlite')
ROOT = Path('/dev/fsq531/codegen-check')
TOOLCHAIN = Path('/workspace/scratch/c21f4a10b42a/rustup-home/toolchains/nightly-2026-08-31-x86_64-unknown-linux-gnu/bin')
BASELINE = 'c5d04545807faf2d135e2dd561e76aa16d5bb95d'

spec = importlib.util.spec_from_file_location('archived_codegen_driver', OLD_DRIVER)
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.REPO = REPO
driver.TOOLCHAIN = TOOLCHAIN

def sha(data):
    return hashlib.sha256(data).hexdigest()

def put(name, data):
    path = ROOT / name
    with path.open('xb') as out:
        out.write(data)
    return path

def main():
    phase = sys.argv[1]
    artifacts = json.loads((ARCHIVE / 'leaf-artifacts.json').read_text())
    environment = driver.build_environment()
    environment['TMPDIR'] = str(ROOT)
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    flags = driver.native_flags(artifacts)
    if phase == 'prepare':
        ROOT.mkdir()
        leaves = subprocess.run(['git','diff','--quiet',BASELINE,'--',*driver.LEAF_PATHS], cwd=REPO)
        assert leaves.returncode == 0, 'Changed leaf source/config'
        source = (REPO / 'crates/fsqlite-vdbe/src/codegen.rs').read_bytes()
        production = (REPO / 'crates/fsqlite-vdbe/src/lib.rs').read_bytes()
        baseline_source = subprocess.check_output(['git','show',BASELINE+':crates/fsqlite-vdbe/src/codegen.rs'], cwd=REPO)
        baseline_lib = subprocess.check_output(['git','show',BASELINE+':crates/fsqlite-vdbe/src/lib.rs'], cwd=REPO)
        assert baseline_source == (ARCHIVE / 'sources/baseline/codegen.rs').read_bytes()
        assert baseline_lib == (ARCHIVE / 'sources/baseline/lib.rs').read_bytes()
        assert production == baseline_lib
        compiler = subprocess.check_output([str(TOOLCHAIN/'rustc'),'-Vv'],text=True)
        assert '90850177249efe0321573c569aec5d12b257f8d6' in compiler
        codegen = put('codegen.rs', source)
        put('lib.rs', production)
        text = production.decode()
        prefix = text.split('pub mod codegen;',1)[0]
        body = text.split('pub mod vectorized_sort;',1)[1].split('// ── PRAGMA Handling',1)[0]
        wrapper = prefix + '#[path = '+json.dumps(str(codegen))+']\npub mod codegen;' + body
        put('codegen_lib.rs', wrapper.encode())
        grouped = (REPO/'crates/fsqlite-vdbe/tests/issue_531_grouped_index_input.rs').read_bytes()
        put('grouped.rs', grouped)
        golden = (REPO/'crates/fsqlite-vdbe/tests/golden_bytecode_snapshots.rs').read_bytes()
        golden_prefix = golden.split(b'fn render_bytecode_case(',1)[0]
        assert len(golden_prefix) < len(golden)
        put('ordered.rs',golden_prefix)
        original_ordered = (ARCHIVE/'sources/tests/issue_531_ordered_lookup_join.rs').read_bytes()
        common_ordered = original_ordered.split(b'#[test]\nfn output_aliases_and_star_ordinals_resolve_once_before_order_proof',1)[0]
        assert len(common_ordered) < len(original_ordered)
        put('common_ordered.rs',common_ordered)
        common = '#[path="grouped.rs"] mod grouped;\n#[path="common_ordered.rs"] mod common_ordered;\n'
        put('baseline_tests.rs',common.encode())
        put('current_tests.rs',(common+'#[path="ordered.rs"] mod ordered;\n').encode())
        metadata = {'scope':driver.SCOPE,'baseline':BASELINE,'candidate_codegen_sha256':sha(source),
                    'candidate_lib_sha256':sha(production),'baseline_codegen_sha256':sha(baseline_source),
                    'grouped_test_sha256':sha(grouped),'golden_full_sha256':sha(golden),
                    'golden_exact_prefix_sha256':sha(golden_prefix),'common_ordered_sha256':sha(common_ordered),
                    'leaf_artifacts_sha256':sha((ARCHIVE/'leaf-artifacts.json').read_bytes()),
                    'reused_baseline_library':str(ARCHIVE/'build/baseline/libfsqlite_codegen_probe.rlib'),
                    'reused_baseline_library_sha256':sha((ARCHIVE/'build/baseline/libfsqlite_codegen_probe.rlib').read_bytes()),
                    'compiler':compiler,'source_selection':'Unchanged complete codegen.rs and production ProgramBuilder/VdbeProgram blocks. Full grouped test file; exact golden prefix before render_bytecode_case; exact archived basic ordered test prefix. No stubs or altered implementation.'}
        put('sources.json',(json.dumps(metadata,indent=2)+'\n').encode())
        print(json.dumps(metadata,indent=2))
        return 0
    common_flags = driver.common_rustc()
    if phase == 'build':
        command = [*common_flags,'--crate-name','fsqlite_codegen_probe','--crate-type','rlib',
                   '--emit=metadata,link',str(ROOT/'codegen_lib.rs'),'--out-dir',str(ROOT),*flags]
        return driver.execute(ROOT,'current-harness-build',command,environment)['exit_code']
    arm = sys.argv[2]
    assert arm in ('current','baseline')
    library_dir = ROOT if arm == 'current' else ARCHIVE/'build/baseline'
    library = library_dir/'libfsqlite_codegen_probe'
    binary = ROOT/(arm+'_tests')
    if phase == 'test-build':
        pair = ['--extern',f'fsqlite_vdbe={library}.rlib','--extern',f'fsqlite_vdbe={library}.rmeta',
                '-L',f'dependency={library_dir}']
        command = [*common_flags,'-C','strip=symbols','--crate-name',arm+'_tests','--test',
                   str(ROOT/(arm+'_tests.rs')),'-o',str(binary),*pair,*flags]
    elif phase == 'run':
        command = [str(binary),'--test-threads=1','--nocapture']
    else:
        raise ValueError(phase)
    return driver.execute(ROOT,arm+'-'+phase,command,environment)['exit_code']

if __name__ == '__main__':
    raise SystemExit(main())
