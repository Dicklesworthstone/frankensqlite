.mode list
.headers off
.print __issue530_81aa2b8ecee949b59eab19405339f4de_0
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_81aa2b8ecee949b59eab19405339f4de_1
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_81aa2b8ecee949b59eab19405339f4de_2
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_81aa2b8ecee949b59eab19405339f4de_3
