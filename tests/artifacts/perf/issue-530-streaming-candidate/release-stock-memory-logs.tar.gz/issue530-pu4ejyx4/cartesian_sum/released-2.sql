.mode list
.headers off
.print __issue530_7f7b3460496f41b4bb884da68e97de21_0
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_7f7b3460496f41b4bb884da68e97de21_1
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_7f7b3460496f41b4bb884da68e97de21_2
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_7f7b3460496f41b4bb884da68e97de21_3
