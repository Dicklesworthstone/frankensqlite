#!/usr/bin/env python3
"""Record a bounded build without changing dependencies or compiler outcomes."""
import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--log', required=True)
p.add_argument('--seconds', type=float, default=1800)
p.add_argument('--max-rss-mib', type=float, default=6656)
p.add_argument('--min-disk-free-mib', type=float, default=256)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ['--'] else a.command
log = Path(a.log)
report = log.with_suffix('.json')
samples = log.with_suffix('.samples.jsonl')
selected = ('CARGO_HOME', 'RUSTUP_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
            'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG',
            'CARGO_PROFILE_DEV_CODEGEN_UNITS', 'CARGO_PROFILE_DEV_LTO',
            'RUSTFLAGS', 'RUSTC_WRAPPER', 'MALLOC_ARENA_MAX', 'RUST_MIN_STACK')
metadata = {'command': command, 'cwd': os.getcwd(),
            'environment': {k: os.environ[k] for k in selected if k in os.environ},
            'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'max_rss_mib': a.max_rss_mib, 'timeout_seconds': a.seconds}
metadata['min_disk_free_mib'] = a.min_disk_free_mib
start = time.monotonic()
peak = 0
reason = None
with log.open('x') as out, samples.open('x') as sampled:
    proc = subprocess.Popen(command, stdout=out, stderr=subprocess.STDOUT,
                            start_new_session=True)
    while proc.poll() is None:
        rss = 0
        names = []
        for entry in Path('/proc').iterdir():
            if not entry.name.isdecimal():
                continue
            try:
                stat = (entry / 'stat').read_text()
                tail = stat.rsplit(')', 1)[1].split()
                if int(tail[2]) != proc.pid:
                    continue
                value = int(tail[21]) * os.sysconf('SC_PAGE_SIZE')
                rss += value
                names.append({'pid': int(entry.name), 'comm': stat.split('(', 1)[1].rsplit(')', 1)[0], 'rss_bytes': value})
            except (FileNotFoundError, PermissionError, ValueError, IndexError):
                continue
        peak = max(peak, rss)
        elapsed = time.monotonic() - start
        filesystem = os.statvfs(os.getcwd())
        disk_unreserved = filesystem.f_bavail * filesystem.f_frsize
        disk_free = (filesystem.f_bfree if os.geteuid() == 0 else filesystem.f_bavail) * filesystem.f_frsize
        try:
            cg = int(Path('/sys/fs/cgroup/memory.current').read_text())
            cgstat = dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())
            anonymous = int(cgstat['anon'])
            shmem = int(cgstat.get('shmem', '0'))
        except (OSError, ValueError, KeyError):
            cg, anonymous, shmem = None, None, None
        sampled.write(json.dumps({'elapsed_seconds': elapsed, 'group_rss_bytes': rss,
                                  'cgroup_memory_bytes': cg, 'cgroup_anon_bytes': anonymous,
                                  'cgroup_shmem_bytes': shmem,
                                  'disk_free_bytes': disk_free,
                                  'disk_unreserved_free_bytes': disk_unreserved,
                                  'processes': names}) + '\n')
        sampled.flush()
        if rss > a.max_rss_mib * 1024 * 1024:
            reason = 'own process-group RSS exceeded configured bound'
        elif anonymous is not None and anonymous + shmem > 7680 * 1024 * 1024 and rss > 512 * 1024 * 1024:
            reason = 'shared cgroup anonymous memory pressure; stopped only this build'
        elif elapsed > a.seconds:
            reason = 'elapsed timeout'
        elif disk_free < a.min_disk_free_mib * 1024 * 1024:
            reason = 'shared disk free space below configured bound; stopped only this build'
        if reason:
            out.write('\nBUILD GUARD: ' + reason + '\n')
            out.flush()
            os.killpg(proc.pid, signal.SIGINT)
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            break
        time.sleep(2)
    code = proc.wait()
metadata.update({'elapsed_seconds': time.monotonic() - start, 'exit_code': code,
                 'guard_reason': reason, 'peak_observed_process_group_rss_bytes': peak,
                 'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
report.write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))
raise SystemExit(code if code >= 0 else 128 - code)
