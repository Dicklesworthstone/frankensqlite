.mode list
.headers off
.print __issue530_f2f97ce9fbb04e709f442f5d2a9aba16_0
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_f2f97ce9fbb04e709f442f5d2a9aba16_1
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_f2f97ce9fbb04e709f442f5d2a9aba16_2
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_f2f97ce9fbb04e709f442f5d2a9aba16_3
