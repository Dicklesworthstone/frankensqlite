.mode list
.headers off
.print __issue530_e0096b82db9a4a868730541de4b9dc30_0
WITH t AS (SELECT value FROM generate_series(1,10000)) SELECT count(*) FROM t WHERE EXISTS(SELECT 1 FROM t t1 WHERE t.value=t1.value);
.print __issue530_e0096b82db9a4a868730541de4b9dc30_1
WITH t AS (SELECT value FROM generate_series(1,10000)) SELECT count(*) FROM t WHERE EXISTS(SELECT 1 FROM t t1 WHERE t.value=t1.value);
.print __issue530_e0096b82db9a4a868730541de4b9dc30_2
