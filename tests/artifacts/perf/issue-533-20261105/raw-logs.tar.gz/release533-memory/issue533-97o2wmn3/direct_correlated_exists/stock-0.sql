.mode list
.headers off
.print __issue530_9908249e278341818c4fa4c777cb540a_0
SELECT count(*) FROM generate_series(1,10000)t WHERE EXISTS(SELECT 1 FROM generate_series(1,10000)t1 WHERE t.value=t1.value);
.print __issue530_9908249e278341818c4fa4c777cb540a_1
SELECT count(*) FROM generate_series(1,10000)t WHERE EXISTS(SELECT 1 FROM generate_series(1,10000)t1 WHERE t.value=t1.value);
.print __issue530_9908249e278341818c4fa4c777cb540a_2
