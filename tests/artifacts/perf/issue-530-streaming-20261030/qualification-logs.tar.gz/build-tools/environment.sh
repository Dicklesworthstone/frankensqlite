export CARGO_HOME=/workspace/scratch/1e2355381366/issue530-build/cargo
export RUSTUP_HOME=/workspace/scratch/1e2355381366/issue530-build/rustup
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/scratch/1e2355381366/issue530-build/target
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_DEV_CODEGEN_UNITS=256
export CARGO_PROFILE_DEV_LTO=false
export RUSTFLAGS='-Zthreads=1 -Cembed-bitcode=no'
export MALLOC_ARENA_MAX=1
