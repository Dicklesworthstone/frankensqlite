.mode list
.headers off
EXPLAIN SELECT count(*) FROM generate_series(1,1000000);
