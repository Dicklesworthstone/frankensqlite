.mode list
.headers off
.print __issue530_c175c890125b4616b642db763acf2c5f_0
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_c175c890125b4616b642db763acf2c5f_1
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_c175c890125b4616b642db763acf2c5f_2
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_c175c890125b4616b642db763acf2c5f_3
