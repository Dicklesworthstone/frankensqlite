.mode list
.headers off
.print __issue530_443b1bcb608348c080965f00e59f7baf_0
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_443b1bcb608348c080965f00e59f7baf_1
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_443b1bcb608348c080965f00e59f7baf_2
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_443b1bcb608348c080965f00e59f7baf_3
