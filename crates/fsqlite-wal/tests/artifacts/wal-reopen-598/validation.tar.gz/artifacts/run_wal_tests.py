"""Run the focused WAL target with a preflight memory gate and exact receipt."""
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess
import sys
import time

root = Path('/workspace/scratch/e1a71523531b')
repo = root / 'frankensqlite'
label = sys.argv[1] if len(sys.argv) > 1 else 'wal-reopen-integration-1'
prefix = root / 'artifacts' / label
config = root / 'artifacts' / 'wal-low-memory.toml'
tracked = ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml',
           'crates/fsqlite-wal/Cargo.toml', 'crates/fsqlite-wal/src/wal.rs',
           'crates/fsqlite-wal/tests/wal_reopen.rs']

def hashes():
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in tracked}

def available():
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):
            return int(line.split()[1])
    raise RuntimeError('MemAvailable unavailable')

def oom_kills():
    for line in Path('/proc/vmstat').read_text().splitlines():
        if line.startswith('oom_kill '):
            return int(line.split()[1])
    return None

command = ['cargo', '-Zprofile-rustflags', '-Zprofile-hint-mostly-unused',
           '--config', str(config), 'test', '--locked', '--offline',
           '-p', 'fsqlite-wal', '--test', 'wal_reopen', '-j', '1']
before = hashes()
patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=repo)
receipt = {
    'command': command, 'repository': str(repo),
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'source_status_before': subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True),
    'source_hashes_before': before, 'source_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'rustc': subprocess.check_output(['rustc', '-Vv'], text=True),
    'config': {'path': str(config), 'content': config.read_text(), 'sha256': hashlib.sha256(config.read_bytes()).hexdigest()},
    'overrides': {key: value for key, value in sorted(os.environ.items())
                  if key.startswith(('CARGO_PROFILE_',)) or key in
                  ['CARGO_TARGET_DIR', 'CARGO_INCREMENTAL', 'CARGO_BUILD_JOBS', 'RUSTFLAGS', 'MALLOC_CONF']},
    'minimum_launch_memory_kib': 5242880,
    'oom_kills_before': oom_kills(),
}
with prefix.with_suffix('.patch').open('xb') as stream:
    stream.write(patch)
with Path(str(prefix) + '-test.rs').open('xb') as stream:
    stream.write((repo / tracked[-1]).read_bytes())
memory = available()
receipt['launch_memory_available_kib'] = memory
if memory < receipt['minimum_launch_memory_kib']:
    receipt.update(returncode=None, stop_reason='Preflight available memory below 5.0 GiB; no compiler launched')
else:
    started = time.monotonic()
    minimum_memory = memory
    minimum_disk = shutil.disk_usage(root).free
    stop_reason = None
    print(json.dumps({'launched': command, 'memory_available_kib': memory, 'log': str(prefix.with_suffix('.log'))}), flush=True)
    with prefix.with_suffix('.log').open('xb') as log:
        process = subprocess.Popen(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        while process.poll() is None:
            time.sleep(1)
            minimum_memory = min(minimum_memory, available())
            minimum_disk = min(minimum_disk, shutil.disk_usage(root).free)
            if minimum_disk < 2 * 1024**3:
                stop_reason = 'Disk headroom fell below 2 GiB'
            elif time.monotonic() - started > 3600:
                stop_reason = 'Test build exceeded 3600 seconds'
            if stop_reason:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
        returncode = process.wait()
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    receipt.update(returncode=returncode, stop_reason=stop_reason,
                   elapsed_seconds=time.monotonic()-started, max_rss_kib=usage.ru_maxrss,
                   user_seconds=usage.ru_utime, system_seconds=usage.ru_stime,
                   minimum_memory_available_kib=minimum_memory,
                   minimum_free_disk_bytes=minimum_disk)
receipt.update(source_hashes_after=hashes(), oom_kills_after=oom_kills())
receipt['source_changed_during_build'] = before != receipt['source_hashes_after']
with Path(str(prefix) + '-receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt, indent=2), flush=True)
sys.exit(3 if receipt['source_changed_during_build'] else (receipt['returncode'] or 0))
