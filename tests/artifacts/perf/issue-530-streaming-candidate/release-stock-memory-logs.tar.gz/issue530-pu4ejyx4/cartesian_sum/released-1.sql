.mode list
.headers off
.print __issue530_c49a130284e6493ba8226dc5ae1f75fb_0
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_c49a130284e6493ba8226dc5ae1f75fb_1
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_c49a130284e6493ba8226dc5ae1f75fb_2
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_c49a130284e6493ba8226dc5ae1f75fb_3
