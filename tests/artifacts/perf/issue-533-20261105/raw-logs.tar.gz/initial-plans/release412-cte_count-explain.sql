.mode list
.headers off
EXPLAIN WITH t AS (SELECT value FROM generate_series(1,1000000)) SELECT count(*) FROM t;
