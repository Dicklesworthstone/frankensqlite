#[test]
fn deferred_scalar_order_parameters_remain_constants() {
    let _serial = serial();
    asupersync::test_utils::run_test(|| async {
        let f = Connection::open(":memory:").await.unwrap();
        let r = rusqlite::Connection::open_in_memory().unwrap();
        f.execute_batch(CORNER_SCHEMA).await.unwrap();
        r.execute_batch(CORNER_SCHEMA).unwrap();

        for term in [
            "?1",
            "+?1",
            "-?1",
            "?1 COLLATE BINARY",
            "(+?1 COLLATE NOCASE) COLLATE RTRIM",
            "-(-(?1 COLLATE BINARY))",
            "(?1 AND p.id)",
        ] {
            // The timestamp and id determine a unique order after the
            // parameter's constant key. Treating its value as an ordinal
            // changes both the order and the rows selected by LIMIT.
            let sql = format!(
                "SELECT p.id,(SELECT count(*) FROM likes l WHERE l.post_id=p.id) \
                 FROM posts p WHERE p.id>0 \
                 ORDER BY {term},p.created_at DESC,p.id DESC LIMIT ?2 OFFSET ?3"
            );
            let prepared = f.prepare(&sql).await.unwrap();
            let mut stock = r.prepare(&sql).unwrap();
            // Reuse one prepared statement across valid, zero, negative and
            // out-of-range ordinal-looking values, then repeat the first.
            for key in [1, 0, -1, 7, i64::MIN, i64::MAX, 1] {
                let params = [key, 2, 0];
                let expected = stock_rows(&mut stock, &params);
                let values = params.map(SqliteValue::Integer);
                let reused = prepared.query_with_params(&values).await.unwrap();
                assert_rows(franken_rows(&reused), expected.clone(), true, &sql);
                let direct = f.query_with_params(&sql, &values).await.unwrap();
                assert_rows(franken_rows(&direct), expected, true, &sql);
            }
        }

        // Literal ordinals retain their original meaning and diagnostics.
        for term in ["1", "+1", "1 COLLATE BINARY", "-(-1) COLLATE BINARY"] {
            let sql = format!(
                "SELECT p.id,(SELECT count(*) FROM likes l WHERE l.post_id=p.id) \
                 FROM posts p ORDER BY {term} DESC LIMIT 2"
            );
            let mut stock = r.prepare(&sql).unwrap();
            let expected = stock_rows::<i64>(&mut stock, &[]);
            let actual = f.query(&sql).await.unwrap();
            assert_rows(franken_rows(&actual), expected, true, &sql);
        }
        for term in ["0", "-1", "3", "+0 COLLATE BINARY", "-4 COLLATE NOCASE"] {
            let sql = format!(
                "SELECT p.id,(SELECT count(*) FROM likes l WHERE l.post_id=p.id) \
                 FROM posts p ORDER BY {term} LIMIT 0"
            );
            assert!(r.prepare(&sql).is_err(), "stock must reject {sql}");
            assert!(
                f.query(&sql).await.is_err(),
                "invalid ordinal accepted: {sql}"
            );
        }
        f.close().await.unwrap();
    });
}
