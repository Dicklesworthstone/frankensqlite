.mode list
.headers off
.print __issue530_48833cee290840368fbfc42b473e631e_0
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_48833cee290840368fbfc42b473e631e_1
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_48833cee290840368fbfc42b473e631e_2
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_48833cee290840368fbfc42b473e631e_3
