.mode list
.headers off
.print __issue530_6dc9786c39d64c2e80d74f70dc6de3ac_0
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_6dc9786c39d64c2e80d74f70dc6de3ac_1
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_6dc9786c39d64c2e80d74f70dc6de3ac_2
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_6dc9786c39d64c2e80d74f70dc6de3ac_3
