.mode list
.headers off
SELECT count(*) FROM generate_series(1,1000000);
