//! Physical-codegen regressions for GH#531's ordered lookup joins.
//!
//! Compile through the public parser and real code generator, then inspect the
//! generated cursor operations and control flow. These assertions establish
//! compiler behavior, not VM execution, SQLite result parity, or measured speed.
//! The corresponding core oracle tests own those runtime checks.

use std::collections::BTreeSet;

use fsqlite_ast::{SortDirection, Statement};
use fsqlite_parser::parse_first_statement_with_tail;
use fsqlite_types::opcode::{
    Opcode, P4, SORTER_COMPARE_TOP_N_PREFLIGHT, SORTER_OPEN_TOP_N_REGISTER, VdbeOp,
};
use fsqlite_vdbe::{
    ProgramBuilder, VdbeProgram,
    codegen::{CodegenContext, CodegenError, ColumnInfo, IndexSchema, TableSchema, codegen_select},
};

fn index(name: &str, root_page: i32, columns: &[&str]) -> IndexSchema {
    IndexSchema {
        name: name.to_owned(),
        root_page,
        columns: columns.iter().map(|name| (*name).to_owned()).collect(),
        key_expressions: columns.iter().map(|name| (*name).to_owned()).collect(),
        key_sort_directions: Vec::new(),
        where_clause: None,
        is_unique: false,
        key_collations: Vec::new(),
        conflict_action: None,
    }
}

fn table(
    name: &str,
    root_page: i32,
    columns: Vec<ColumnInfo>,
    indexes: Vec<IndexSchema>,
) -> TableSchema {
    TableSchema {
        name: name.to_owned(),
        root_page,
        columns,
        indexes,
        strict: false,
        without_rowid: false,
        primary_key_constraints: Vec::new(),
        foreign_keys: Vec::new(),
        check_constraints: Vec::new(),
    }
}

fn schema() -> Vec<TableSchema> {
    let mut ordered = index("posts_created_at_id", 10, &["created_at", "id"]);
    ordered.key_sort_directions = vec![SortDirection::Desc, SortDirection::Desc];
    vec![
        table(
            "posts",
            2,
            vec![
                ColumnInfo::basic("id", 'D', true),
                ColumnInfo::basic("user_id", 'D', false),
                ColumnInfo::basic("created_at", 'B', false),
                ColumnInfo::basic("body", 'B', false),
            ],
            vec![ordered, index("posts_user_id", 11, &["user_id"])],
        ),
        table(
            "users",
            3,
            vec![
                ColumnInfo::basic("id", 'D', true),
                ColumnInfo::basic("username", 'B', false),
            ],
            Vec::new(),
        ),
        table(
            "likes",
            4,
            vec![
                ColumnInfo::basic("id", 'D', true),
                ColumnInfo::basic("post_id", 'D', false),
                ColumnInfo::basic("user_id", 'D', false),
            ],
            vec![index("likes_post_id", 12, &["post_id"])],
        ),
    ]
}

fn compile_with_context(
    sql: &str,
    schema: &[TableSchema],
    context: &CodegenContext,
) -> VdbeProgram {
    let (statement, consumed) = parse_first_statement_with_tail(sql)
        .expect("regression SQL must parse")
        .expect("regression SQL must contain a statement");
    assert_eq!(consumed, sql.len(), "unparsed SQL: {sql}");
    let Statement::Select(select) = statement else {
        panic!("expected SELECT: {sql}");
    };
    let mut builder = ProgramBuilder::new();
    codegen_select(&mut builder, &select, schema, context)
        .unwrap_or_else(|error| panic!("codegen failed for {sql}: {error}"));
    // finish() validates jump targets and resolves the real emitter's labels.
    let program = builder
        .finish()
        .unwrap_or_else(|error| panic!("unresolved program for {sql}: {error}"));
    assert_eq!(program.ops().last().map(|op| op.opcode), Some(Opcode::Halt));
    program
}

fn compile(sql: &str, schema: &[TableSchema]) -> VdbeProgram {
    compile_with_context(
        sql,
        schema,
        &CodegenContext {
            index_ordered_scan_reliable: true,
            ..CodegenContext::default()
        },
    )
}

fn index_cursor(program: &VdbeProgram, name: &str) -> Option<i32> {
    program.ops().iter().find_map(|op| {
        (op.opcode == Opcode::OpenRead && matches!(&op.p4, P4::Index(index) if index == name))
            .then_some(op.p1)
    })
}

fn table_cursor(program: &VdbeProgram, name: &str) -> i32 {
    program
        .ops()
        .iter()
        .find_map(|op| {
            (op.opcode == Opcode::OpenRead && matches!(&op.p4, P4::Table(table) if table == name))
                .then_some(op.p1)
        })
        .unwrap_or_else(|| panic!("missing table cursor for {name}"))
}

fn first_op(program: &VdbeProgram, opcode: Opcode) -> &VdbeOp {
    program
        .ops()
        .iter()
        .find(|op| op.opcode == opcode)
        .unwrap_or_else(|| panic!("missing {opcode:?}"))
}

fn variable_register(program: &VdbeProgram, slot: i32) -> i32 {
    program
        .ops()
        .iter()
        .find_map(|op| (op.opcode == Opcode::Variable && op.p1 == slot).then_some(op.p2))
        .unwrap_or_else(|| panic!("missing bind slot {slot}"))
}

fn bind_slots(program: &VdbeProgram) -> BTreeSet<i32> {
    program
        .ops()
        .iter()
        .filter_map(|op| (op.opcode == Opcode::Variable).then_some(op.p1))
        .collect()
}

fn assert_ordered_outer_index(program: &VdbeProgram, direction: SortDirection) {
    let outer = table_cursor(program, "posts");
    let cursor = index_cursor(program, "posts_created_at_id")
        .expect("ordered lookup join must open the outer ordering index");
    let (start, advance) = if direction == SortDirection::Desc {
        // The stored index itself has DESC keys.
        (Opcode::Rewind, Opcode::Next)
    } else {
        (Opcode::Last, Opcode::Prev)
    };
    for opcode in [start, advance, Opcode::IdxRowid] {
        assert!(
            program
                .ops()
                .iter()
                .any(|op| op.opcode == opcode && op.p1 == cursor),
            "outer index must emit {opcode:?}"
        );
    }
    assert!(
        program
            .ops()
            .iter()
            .any(|op| op.opcode == Opcode::SeekRowid && op.p1 == outer)
    );
    assert!(
        !program
            .ops()
            .iter()
            .any(|op| op.opcode == Opcode::Rewind && op.p1 == outer),
        "ordered input must not also scan the outer table"
    );
    assert!(
        !program
            .ops()
            .iter()
            .any(|op| op.opcode == Opcode::SorterOpen),
        "a complete proven outer order must not materialize a sorter"
    );
    assert!(
        program
            .ops()
            .iter()
            .any(|op| op.opcode == Opcode::DecrJumpZero),
        "the streamed result must still enforce LIMIT"
    );
}

const LOOKUP: &str = "SELECT p.id,u.username FROM posts p JOIN users u ON u.id=p.user_id";

#[test]
fn ordered_outer_index_walk_streams_forward_and_reverse() {
    let schema = schema();
    for (direction, sql_direction) in [(SortDirection::Desc, "DESC"), (SortDirection::Asc, "ASC")] {
        let sql = format!(
            "{LOOKUP} ORDER BY p.created_at {sql_direction},p.id {sql_direction} LIMIT ?1 OFFSET ?2"
        );
        let program = compile(&sql, &schema);
        assert_ordered_outer_index(&program, direction);
        assert_eq!(bind_slots(&program), BTreeSet::from([1, 2]));
        let users = table_cursor(&program, "users");
        assert!(
            program
                .ops()
                .iter()
                .any(|op| op.opcode == Opcode::SeekRowid && op.p1 == users)
        );
        assert!(
            !program
                .ops()
                .iter()
                .any(|op| op.opcode == Opcode::Rewind && op.p1 == users)
        );
    }
}

