.mode list
.headers off
.print __issue530_46183e0f72194f2da08c48d9dc3c8329_0
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_46183e0f72194f2da08c48d9dc3c8329_1
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_46183e0f72194f2da08c48d9dc3c8329_2
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_46183e0f72194f2da08c48d9dc3c8329_3
