#!/usr/bin/env python3
"""Wait for shared-memory headroom, then exec the requested rustc unchanged."""
import json
import os
from pathlib import Path
import sys
import time

args = sys.argv[1:]
crate = args[args.index('--crate-name') + 1] if '--crate-name' in args else None
# These large crates must not compete with another large compiler. Ordinary
# dependencies can use available headroom while a neighboring build finishes.
threshold_mib = 3072 if crate in ('asupersync', 'fsqlite_core') else 6144
started = time.monotonic()
if crate == 'fsqlite_core' and any(a.startswith('--emit=') and 'link' in a for a in args):
    marker = Path('/workspace/scratch/1e2355381366/issue530-build/allow-native-core')
    if not marker.exists():
        print('BUILD ADMISSION: core codegen waiting for task storage checkpoint', file=sys.stderr, flush=True)
    while not marker.exists():
        if time.monotonic() - started > 600:
            print('BUILD ADMISSION: task storage checkpoint timed out', file=sys.stderr)
            raise SystemExit(75)
        time.sleep(2)
while crate:
    stat = dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())
    occupied = int(stat['anon']) + int(stat.get('shmem', '0'))
    if occupied <= threshold_mib * 1024 * 1024:
        break
    if time.monotonic() - started > 600:
        print(f'BUILD ADMISSION: shared memory did not permit {crate} within600s', file=sys.stderr)
        raise SystemExit(75)
    time.sleep(2)
with Path('/workspace/scratch/1e2355381366/issue530-build/logs/rustc-invocations.jsonl').open('a') as out:
    out.write(json.dumps({'crate': crate, 'wait_seconds': time.monotonic() - started,
                          'threshold_mib': threshold_mib, 'args': args}) + '\n')
os.execv(args[0], args)
