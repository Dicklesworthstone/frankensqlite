.mode list
.headers off
.print __issue530_47c999a171c04d1cb07a72eb530b5448_0
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_47c999a171c04d1cb07a72eb530b5448_1
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_47c999a171c04d1cb07a72eb530b5448_2
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_47c999a171c04d1cb07a72eb530b5448_3
