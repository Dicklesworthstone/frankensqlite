#!/usr/bin/env python3
"""Run only this task's compiler process group with bounded resource usage."""
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time


def resources():
    stat = dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())
    hard = sum(int(stat.get(key, 0)) for key in ('anon', 'shmem', 'slab_unreclaimable', 'pagetables', 'kernel_stack'))
    fs = os.statvfs('/tmp')
    return {
        'memory_current': int(Path('/sys/fs/cgroup/memory.current').read_text()),
        'memory_limit': int(Path('/sys/fs/cgroup/memory.max').read_text()),
        'nonreclaimable_estimate': hard,
        'disk_physical_free': fs.f_bfree * fs.f_bsize,
    }


def child_limits():
    cap = 900000 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (cap, cap))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def main():
    output = Path(sys.argv[1])
    command = sys.argv[2:]
    before = resources()
    record = {'command': command, 'cwd': os.getcwd(), 'virtual_memory_cap_bytes': 900000 * 1024, 'before': before}
    if before['disk_physical_free'] < 12 * 1024 * 1024:
        record['guard_reason'] = 'insufficient physical disk space before launch'
        record['exit_code'] = 75
    elif before['nonreclaimable_estimate'] > before['memory_limit'] - 512 * 1024 * 1024:
        record['guard_reason'] = 'insufficient shared memory headroom before launch'
        record['exit_code'] = 75
    else:
        started = time.monotonic()
        reason = None
        peak = before['nonreclaimable_estimate']
        with output.with_suffix('.stdout').open('w') as stdout, output.with_suffix('.stderr').open('w') as stderr:
            process = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True, preexec_fn=child_limits)
            while process.poll() is None:
                state = resources()
                peak = max(peak, state['nonreclaimable_estimate'])
                if state['disk_physical_free'] < 8 * 1024 * 1024:
                    reason = 'physical disk free below 8 MiB'
                elif state['nonreclaimable_estimate'] > state['memory_limit'] - 384 * 1024 * 1024:
                    reason = 'shared memory headroom below 384 MiB'
                elif time.monotonic() - started > 300:
                    reason = '300-second compiler time bound exceeded'
                if reason:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
                    break
                time.sleep(0.25)
        record.update(exit_code=process.returncode, guard_reason=reason, elapsed_seconds=time.monotonic()-started, peak_nonreclaimable_estimate=peak)
    record['after'] = resources()
    output.with_suffix('.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record))
    return record['exit_code'] if record['exit_code'] >= 0 else 128 - record['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
