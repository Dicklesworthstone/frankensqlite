.mode list
.headers off
.print __issue530_c1fd72504d934510be7841af851ec141_0
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_c1fd72504d934510be7841af851ec141_1
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_c1fd72504d934510be7841af851ec141_2
SELECT count(*) FROM generate_series(1,1000000) HAVING count(*)>=0;
.print __issue530_c1fd72504d934510be7841af851ec141_3
