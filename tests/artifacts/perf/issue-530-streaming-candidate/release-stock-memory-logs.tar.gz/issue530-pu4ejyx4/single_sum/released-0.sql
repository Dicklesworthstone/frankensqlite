.mode list
.headers off
.print __issue530_833fcf292d8d4013a82f406143f7b795_0
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_833fcf292d8d4013a82f406143f7b795_1
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_833fcf292d8d4013a82f406143f7b795_2
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_833fcf292d8d4013a82f406143f7b795_3
