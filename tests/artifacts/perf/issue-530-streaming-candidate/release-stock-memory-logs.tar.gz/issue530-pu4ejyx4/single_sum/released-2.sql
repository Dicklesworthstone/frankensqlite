.mode list
.headers off
.print __issue530_be449906454b4afda3c5d9483a314e0e_0
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_be449906454b4afda3c5d9483a314e0e_1
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_be449906454b4afda3c5d9483a314e0e_2
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_be449906454b4afda3c5d9483a314e0e_3
