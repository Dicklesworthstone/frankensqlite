.mode list
.headers off
.print __issue530_48bc7d7bdfd44e62a672058b62ad134d_0
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_48bc7d7bdfd44e62a672058b62ad134d_1
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_48bc7d7bdfd44e62a672058b62ad134d_2
SELECT count(*) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_48bc7d7bdfd44e62a672058b62ad134d_3
