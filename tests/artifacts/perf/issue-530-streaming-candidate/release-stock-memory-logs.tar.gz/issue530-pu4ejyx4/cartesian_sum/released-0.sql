.mode list
.headers off
.print __issue530_35b5b5f19d864e7bacbb55a1b8828cfd_0
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_35b5b5f19d864e7bacbb55a1b8828cfd_1
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_35b5b5f19d864e7bacbb55a1b8828cfd_2
SELECT sum((a.value-1)*1000+b.value) FROM generate_series(1,1000)a,generate_series(1,1000)b;
.print __issue530_35b5b5f19d864e7bacbb55a1b8828cfd_3
