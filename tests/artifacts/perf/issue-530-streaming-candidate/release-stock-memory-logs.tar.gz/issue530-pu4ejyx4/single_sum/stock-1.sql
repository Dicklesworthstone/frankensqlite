.mode list
.headers off
.print __issue530_8e0313fd4f00437ea2882f6c35726f45_0
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_8e0313fd4f00437ea2882f6c35726f45_1
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_8e0313fd4f00437ea2882f6c35726f45_2
SELECT sum(value) FROM generate_series(1,1000000);
.print __issue530_8e0313fd4f00437ea2882f6c35726f45_3
