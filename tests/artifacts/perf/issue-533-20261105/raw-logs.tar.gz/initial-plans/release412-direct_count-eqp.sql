.mode list
.headers off
EXPLAIN QUERY PLAN SELECT count(*) FROM generate_series(1,1000000);
