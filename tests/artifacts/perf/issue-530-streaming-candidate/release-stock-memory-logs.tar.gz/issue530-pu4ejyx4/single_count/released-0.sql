.mode list
.headers off
.print __issue530_f785af1993ae4eddb66d50dc79cddb9f_0
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_f785af1993ae4eddb66d50dc79cddb9f_1
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_f785af1993ae4eddb66d50dc79cddb9f_2
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_f785af1993ae4eddb66d50dc79cddb9f_3
