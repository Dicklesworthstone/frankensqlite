.mode list
.headers off
.timer on
SELECT count(*) FROM generate_series(1,1000000);
.timer off
