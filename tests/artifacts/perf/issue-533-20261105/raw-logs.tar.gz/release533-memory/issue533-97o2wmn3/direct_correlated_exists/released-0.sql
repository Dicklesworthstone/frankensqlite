.mode list
.headers off
.print __issue530_dca654d1a6024945958b8d835bae2345_0
SELECT count(*) FROM generate_series(1,10000)t WHERE EXISTS(SELECT 1 FROM generate_series(1,10000)t1 WHERE t.value=t1.value);
.print __issue530_dca654d1a6024945958b8d835bae2345_1
SELECT count(*) FROM generate_series(1,10000)t WHERE EXISTS(SELECT 1 FROM generate_series(1,10000)t1 WHERE t.value=t1.value);
.print __issue530_dca654d1a6024945958b8d835bae2345_2
