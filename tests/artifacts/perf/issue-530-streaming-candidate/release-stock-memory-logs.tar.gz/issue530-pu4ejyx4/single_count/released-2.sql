.mode list
.headers off
.print __issue530_603513eab218494a90051e87219b05c0_0
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_603513eab218494a90051e87219b05c0_1
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_603513eab218494a90051e87219b05c0_2
SELECT count(*) FROM generate_series(1,1000000);
.print __issue530_603513eab218494a90051e87219b05c0_3
